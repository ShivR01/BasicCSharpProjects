﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tax_Calc
{
    class Program
    {
        public static double[] TaxAmnt2 = new double[5];
        static void Main(string[] args)
        {

            for (int i = 0; i < 5; i++)
            {
                Console.WriteLine("Enter name");
                String name = Console.ReadLine();

                Console.WriteLine("Enter age");
                int age = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("Enter income");
                double inc = Convert.ToDouble(Console.ReadLine());

                double taxAmnt = calcTax(inc);
                Console.WriteLine(taxAmnt);
                double rebateAmnt = calcRebate(age);
                Console.WriteLine(rebateAmnt);
                double actualTax = taxAmnt - rebateAmnt;
                TaxAmnt2[i] = actualTax;
                Console.WriteLine(actualTax);
            }
            displayArray();

        }
        public static double calcTax(double income)
        {
            double taxAmnt = 0;

            if (income < 195850)
            {
                taxAmnt = taxAmnt * 0.18;
            }
            else if (income < 305850)
            {
                taxAmnt = 35232 + ((income - 195850) * 0.26);
            }
            else if (income < 423300)
            {
                taxAmnt = 63853 + ((income - 305850) * 0.31);
            }
            else if (income < 555600)
            {
                taxAmnt = 100263 + ((income - 423300) * 0.36);
            }
            else if (income < 708310)
            {
                taxAmnt = 147891 + ((income - 555600) * 0.39);
            }
            else if (income < 1500000)
            {
                taxAmnt = 207448 + ((income - 708310) * 0.41);
            }
            else if (income > 1500001)
            {
                taxAmnt = 532041 + ((income - 1500000) * 0.45);
            }

            

            return taxAmnt;

        }
        public static double calcRebate(int age)
        {
            double rebate = 0;

            if (age < 65)
            {
                rebate = 14067;
            }
            else if (age < 75)
            {
                rebate = 7713;
            }
            else rebate = 2574;



            return rebate;
        }

        public static void displayArray()
        {
            for (int i = 0; i < 5; i++)
            {
               Console.WriteLine(TaxAmnt2[i]);
            }
        }

    }

}

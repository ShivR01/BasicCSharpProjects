﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cinema
{           //Shivaar Sanparsad(18003959)
    public partial class Form1 : Form
    {
        String[,] seats = new string[10,10]; //put in class
        String[,] names = new string[10,10]; //put in class
        Seat seat = new Seat();

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            String seatTot;
            seat.Name = textBox2.Text;
            seat.Row = seat.rowNum(textBox3.Text);   //converts letter to number
            seat.Number = textBox4.Text;

            seatTot = textBox3.Text + seat.Number;       //Combines letter and number

            if (seats[Convert.ToInt16(seat.Row) - 1, (Convert.ToInt16(seat.Number)) - 1] == seatTot)// checks if seat is unavailable
            {
                MessageBox.Show("Sorry that seat is taken by "+(names[Convert.ToInt16(seat.Row) - 1, (Convert.ToInt16(seat.Number)) - 1]) + " Please select an unchecked seat");
            }
            else {

                seats[Convert.ToInt16(seat.Row) - 1, (Convert.ToInt16(seat.Number)) - 1] = seatTot;        //populates 2d array
                names[Convert.ToInt16(seat.Row) - 1, (Convert.ToInt16(seat.Number)) - 1] = seat.Name;      //populates 2d array

                foreach (Control c in Controls)        // checks all checkboxes according to the user input
                {
                    if (c is CheckBox)
                    {
                        CheckBox cb = (CheckBox)c;

                        if (cb.Name == seatTot)
                        {
                            cb.Checked = true;
                        }
                    }
                }
            }
        }

        private void button2_Click(object sender, EventArgs e) { 
    
            seat.searchSeat(seats , comboBox1.SelectedItem+"", names);
           
        }





        

     
    }
}

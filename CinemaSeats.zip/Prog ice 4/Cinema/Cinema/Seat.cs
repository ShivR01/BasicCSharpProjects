﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cinema
{      //Shivaar Sanparsad(18003959)
    class Seat
    {
        private String name;
        private String row;
        private String number;
        private String search;

    

        public string Name { get => name; set => name = value; }
        public string Row { get => row; set => row = value; }
        public string Number { get => number; set => number = value; }
        public string Search { get => search; set => search = value; }

        public String rowNum(String letter) {   //gets user input of the selected letter and converts it to a number
            String row;
            switch (letter)
            {
                case "A": row = "1";
                    break;
                case "B":
                    row = "2";
                    break;
                case "C":
                    row = "3";
                    break;
                case "D":
                    row = "4";
                    break;
                case "E":
                    row = "5";
                    break;
                case "F":
                    row = "6";
                    break;
                case "G":
                    row = "7";
                    break;
                case "H":
                    row = "8";
                    break;
                case "I":
                    row = "9";
                    break;
                case "J":
                    row = "10";
                    break;

                default:
                    throw new IllegalArgumentException("Invalid letter inputted: " + letter); 

            }

            return row;
        }

        public  void searchSeat(String[,] a, String item, String[,] n) {
            int count = 0;
            for (int i = 0; i < 10; i++)
            {                                           //searches the 2d array 
                for (int j = 0; j < 10; j++)
                {
                    if (a[i, j] == item)            //if any item in the 2d array equals the selected text from the combobox then it displays an error message followed by the customers name 
                    {
                        System.Windows.Forms.MessageBox.Show("Sorry that seat is taken by "+n[i,j]);
                        count = 1;
                    }
                }
            }

            if (count == 0)
            {
                System.Windows.Forms.MessageBox.Show("Seat available");
            }
        }


    }

}

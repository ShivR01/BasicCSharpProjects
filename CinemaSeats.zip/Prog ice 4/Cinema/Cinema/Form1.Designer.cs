﻿namespace Cinema
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.button2 = new System.Windows.Forms.Button();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.J10 = new System.Windows.Forms.CheckBox();
            this.J9 = new System.Windows.Forms.CheckBox();
            this.J8 = new System.Windows.Forms.CheckBox();
            this.J7 = new System.Windows.Forms.CheckBox();
            this.J6 = new System.Windows.Forms.CheckBox();
            this.J5 = new System.Windows.Forms.CheckBox();
            this.J4 = new System.Windows.Forms.CheckBox();
            this.J3 = new System.Windows.Forms.CheckBox();
            this.J2 = new System.Windows.Forms.CheckBox();
            this.J1 = new System.Windows.Forms.CheckBox();
            this.I10 = new System.Windows.Forms.CheckBox();
            this.I9 = new System.Windows.Forms.CheckBox();
            this.I8 = new System.Windows.Forms.CheckBox();
            this.I7 = new System.Windows.Forms.CheckBox();
            this.I6 = new System.Windows.Forms.CheckBox();
            this.I5 = new System.Windows.Forms.CheckBox();
            this.I4 = new System.Windows.Forms.CheckBox();
            this.I3 = new System.Windows.Forms.CheckBox();
            this.I2 = new System.Windows.Forms.CheckBox();
            this.I1 = new System.Windows.Forms.CheckBox();
            this.H10 = new System.Windows.Forms.CheckBox();
            this.H9 = new System.Windows.Forms.CheckBox();
            this.H8 = new System.Windows.Forms.CheckBox();
            this.H7 = new System.Windows.Forms.CheckBox();
            this.H6 = new System.Windows.Forms.CheckBox();
            this.H5 = new System.Windows.Forms.CheckBox();
            this.H4 = new System.Windows.Forms.CheckBox();
            this.H3 = new System.Windows.Forms.CheckBox();
            this.H2 = new System.Windows.Forms.CheckBox();
            this.H1 = new System.Windows.Forms.CheckBox();
            this.G10 = new System.Windows.Forms.CheckBox();
            this.G9 = new System.Windows.Forms.CheckBox();
            this.G8 = new System.Windows.Forms.CheckBox();
            this.G7 = new System.Windows.Forms.CheckBox();
            this.G6 = new System.Windows.Forms.CheckBox();
            this.G5 = new System.Windows.Forms.CheckBox();
            this.G4 = new System.Windows.Forms.CheckBox();
            this.G3 = new System.Windows.Forms.CheckBox();
            this.G2 = new System.Windows.Forms.CheckBox();
            this.G1 = new System.Windows.Forms.CheckBox();
            this.F10 = new System.Windows.Forms.CheckBox();
            this.F9 = new System.Windows.Forms.CheckBox();
            this.F8 = new System.Windows.Forms.CheckBox();
            this.F7 = new System.Windows.Forms.CheckBox();
            this.F6 = new System.Windows.Forms.CheckBox();
            this.F5 = new System.Windows.Forms.CheckBox();
            this.F4 = new System.Windows.Forms.CheckBox();
            this.F3 = new System.Windows.Forms.CheckBox();
            this.F2 = new System.Windows.Forms.CheckBox();
            this.F1 = new System.Windows.Forms.CheckBox();
            this.E10 = new System.Windows.Forms.CheckBox();
            this.E9 = new System.Windows.Forms.CheckBox();
            this.E8 = new System.Windows.Forms.CheckBox();
            this.E7 = new System.Windows.Forms.CheckBox();
            this.E6 = new System.Windows.Forms.CheckBox();
            this.E5 = new System.Windows.Forms.CheckBox();
            this.E4 = new System.Windows.Forms.CheckBox();
            this.E3 = new System.Windows.Forms.CheckBox();
            this.E2 = new System.Windows.Forms.CheckBox();
            this.E1 = new System.Windows.Forms.CheckBox();
            this.D10 = new System.Windows.Forms.CheckBox();
            this.D9 = new System.Windows.Forms.CheckBox();
            this.D8 = new System.Windows.Forms.CheckBox();
            this.D7 = new System.Windows.Forms.CheckBox();
            this.D6 = new System.Windows.Forms.CheckBox();
            this.D5 = new System.Windows.Forms.CheckBox();
            this.D4 = new System.Windows.Forms.CheckBox();
            this.D3 = new System.Windows.Forms.CheckBox();
            this.D2 = new System.Windows.Forms.CheckBox();
            this.D1 = new System.Windows.Forms.CheckBox();
            this.A10 = new System.Windows.Forms.CheckBox();
            this.A9 = new System.Windows.Forms.CheckBox();
            this.A8 = new System.Windows.Forms.CheckBox();
            this.A7 = new System.Windows.Forms.CheckBox();
            this.A6 = new System.Windows.Forms.CheckBox();
            this.A5 = new System.Windows.Forms.CheckBox();
            this.A4 = new System.Windows.Forms.CheckBox();
            this.A3 = new System.Windows.Forms.CheckBox();
            this.A2 = new System.Windows.Forms.CheckBox();
            this.A1 = new System.Windows.Forms.CheckBox();
            this.C10 = new System.Windows.Forms.CheckBox();
            this.C9 = new System.Windows.Forms.CheckBox();
            this.C8 = new System.Windows.Forms.CheckBox();
            this.C7 = new System.Windows.Forms.CheckBox();
            this.C6 = new System.Windows.Forms.CheckBox();
            this.C5 = new System.Windows.Forms.CheckBox();
            this.C4 = new System.Windows.Forms.CheckBox();
            this.C3 = new System.Windows.Forms.CheckBox();
            this.C2 = new System.Windows.Forms.CheckBox();
            this.C1 = new System.Windows.Forms.CheckBox();
            this.B10 = new System.Windows.Forms.CheckBox();
            this.B9 = new System.Windows.Forms.CheckBox();
            this.B8 = new System.Windows.Forms.CheckBox();
            this.B7 = new System.Windows.Forms.CheckBox();
            this.B6 = new System.Windows.Forms.CheckBox();
            this.B5 = new System.Windows.Forms.CheckBox();
            this.B4 = new System.Windows.Forms.CheckBox();
            this.B3 = new System.Windows.Forms.CheckBox();
            this.B2 = new System.Windows.Forms.CheckBox();
            this.B1 = new System.Windows.Forms.CheckBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // textBox1
            // 
            this.textBox1.Enabled = false;
            this.textBox1.Location = new System.Drawing.Point(81, 21);
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(135, 20);
            this.textBox1.TabIndex = 0;
            this.textBox1.Text = "               Screen";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.textBox4);
            this.panel2.Controls.Add(this.button1);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.textBox3);
            this.panel2.Controls.Add(this.textBox2);
            this.panel2.Location = new System.Drawing.Point(326, 47);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(200, 115);
            this.panel2.TabIndex = 2;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(3, 70);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(47, 13);
            this.label4.TabIndex = 5;
            this.label4.Text = "Number:";
            
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(86, 67);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(100, 20);
            this.textBox4.TabIndex = 4;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(111, 89);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 3;
            this.button1.Text = "Assign";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(3, 44);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(32, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Row:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(3, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(38, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Name:";
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(86, 41);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(100, 20);
            this.textBox3.TabIndex = 1;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(86, 15);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 20);
            this.textBox2.TabIndex = 0;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.button2);
            this.panel3.Controls.Add(this.comboBox1);
            this.panel3.Controls.Add(this.label3);
            this.panel3.Location = new System.Drawing.Point(326, 168);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(200, 100);
            this.panel3.TabIndex = 4;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(111, 52);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 5;
            this.button2.Text = "Search";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "A1",
            "A2",
            "A3",
            "A4",
            "A5",
            "A6",
            "A7",
            "A8",
            "A9",
            "A10",
            "B1",
            "B2",
            "B3",
            "B4",
            "B5",
            "B6",
            "B7",
            "B8",
            "B9",
            "B10",
            "C1",
            "C2",
            "C3",
            "C4",
            "C5",
            "C6",
            "C7",
            "C8",
            "C9",
            "C10",
            "D1",
            "D2",
            "D3",
            "D4",
            "D5",
            "D6",
            "D7",
            "D8",
            "D9",
            "D10",
            "E1",
            "E2",
            "E3",
            "E4",
            "E5",
            "E6",
            "E7",
            "E8",
            "E9",
            "E10",
            "F1",
            "F2",
            "F3",
            "F4",
            "F5",
            "F6",
            "F7",
            "F8",
            "F9",
            "F10",
            "G1",
            "G2",
            "G3",
            "G4",
            "G5",
            "G6",
            "G7",
            "G8",
            "G9",
            "G10",
            "H1",
            "H2",
            "H3",
            "H4",
            "H5",
            "H6",
            "H7",
            "H8",
            "H9",
            "H10",
            "I1",
            "I2",
            "I3",
            "I4",
            "I5",
            "I6",
            "I7",
            "I8",
            "I9",
            "I10",
            "J1",
            "J2",
            "J3",
            "J4",
            "J5",
            "J6",
            "J7",
            "J8",
            "J9",
            "J10"});
            this.comboBox1.Location = new System.Drawing.Point(86, 14);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(98, 21);
            this.comboBox1.TabIndex = 5;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 17);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(65, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "Select Seat:";
            // 
            // J10
            // 
            this.J10.AutoSize = true;
            this.J10.Location = new System.Drawing.Point(256, 248);
            this.J10.Name = "J10";
            this.J10.Size = new System.Drawing.Size(15, 14);
            this.J10.TabIndex = 210;
            this.J10.UseVisualStyleBackColor = true;
            // 
            // J9
            // 
            this.J9.AutoSize = true;
            this.J9.Location = new System.Drawing.Point(235, 248);
            this.J9.Name = "J9";
            this.J9.Size = new System.Drawing.Size(15, 14);
            this.J9.TabIndex = 209;
            this.J9.UseVisualStyleBackColor = true;
            // 
            // J8
            // 
            this.J8.AutoSize = true;
            this.J8.Location = new System.Drawing.Point(214, 248);
            this.J8.Name = "J8";
            this.J8.Size = new System.Drawing.Size(15, 14);
            this.J8.TabIndex = 208;
            this.J8.UseVisualStyleBackColor = true;
            // 
            // J7
            // 
            this.J7.AutoSize = true;
            this.J7.Location = new System.Drawing.Point(193, 248);
            this.J7.Name = "J7";
            this.J7.Size = new System.Drawing.Size(15, 14);
            this.J7.TabIndex = 207;
            this.J7.UseVisualStyleBackColor = true;
            // 
            // J6
            // 
            this.J6.AutoSize = true;
            this.J6.Location = new System.Drawing.Point(173, 248);
            this.J6.Name = "J6";
            this.J6.Size = new System.Drawing.Size(15, 14);
            this.J6.TabIndex = 206;
            this.J6.UseVisualStyleBackColor = true;
            // 
            // J5
            // 
            this.J5.AutoSize = true;
            this.J5.Location = new System.Drawing.Point(123, 248);
            this.J5.Name = "J5";
            this.J5.Size = new System.Drawing.Size(15, 14);
            this.J5.TabIndex = 205;
            this.J5.UseVisualStyleBackColor = true;
            // 
            // J4
            // 
            this.J4.AutoSize = true;
            this.J4.Location = new System.Drawing.Point(102, 248);
            this.J4.Name = "J4";
            this.J4.Size = new System.Drawing.Size(15, 14);
            this.J4.TabIndex = 204;
            this.J4.UseVisualStyleBackColor = true;
            // 
            // J3
            // 
            this.J3.AutoSize = true;
            this.J3.Location = new System.Drawing.Point(81, 248);
            this.J3.Name = "J3";
            this.J3.Size = new System.Drawing.Size(15, 14);
            this.J3.TabIndex = 203;
            this.J3.UseVisualStyleBackColor = true;
            // 
            // J2
            // 
            this.J2.AutoSize = true;
            this.J2.Location = new System.Drawing.Point(60, 248);
            this.J2.Name = "J2";
            this.J2.Size = new System.Drawing.Size(15, 14);
            this.J2.TabIndex = 202;
            this.J2.UseVisualStyleBackColor = true;
            // 
            // J1
            // 
            this.J1.AutoSize = true;
            this.J1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.J1.Location = new System.Drawing.Point(40, 248);
            this.J1.Name = "J1";
            this.J1.Size = new System.Drawing.Size(15, 14);
            this.J1.TabIndex = 201;
            this.J1.UseVisualStyleBackColor = true;
            // 
            // I10
            // 
            this.I10.AutoSize = true;
            this.I10.Location = new System.Drawing.Point(256, 228);
            this.I10.Name = "I10";
            this.I10.Size = new System.Drawing.Size(15, 14);
            this.I10.TabIndex = 200;
            this.I10.UseVisualStyleBackColor = true;
            // 
            // I9
            // 
            this.I9.AutoSize = true;
            this.I9.Location = new System.Drawing.Point(235, 228);
            this.I9.Name = "I9";
            this.I9.Size = new System.Drawing.Size(15, 14);
            this.I9.TabIndex = 199;
            this.I9.UseVisualStyleBackColor = true;
            // 
            // I8
            // 
            this.I8.AutoSize = true;
            this.I8.Location = new System.Drawing.Point(214, 228);
            this.I8.Name = "I8";
            this.I8.Size = new System.Drawing.Size(15, 14);
            this.I8.TabIndex = 198;
            this.I8.UseVisualStyleBackColor = true;
            // 
            // I7
            // 
            this.I7.AutoSize = true;
            this.I7.Location = new System.Drawing.Point(193, 228);
            this.I7.Name = "I7";
            this.I7.Size = new System.Drawing.Size(15, 14);
            this.I7.TabIndex = 197;
            this.I7.UseVisualStyleBackColor = true;
            // 
            // I6
            // 
            this.I6.AutoSize = true;
            this.I6.Location = new System.Drawing.Point(173, 228);
            this.I6.Name = "I6";
            this.I6.Size = new System.Drawing.Size(15, 14);
            this.I6.TabIndex = 196;
            this.I6.UseVisualStyleBackColor = true;
            // 
            // I5
            // 
            this.I5.AutoSize = true;
            this.I5.Location = new System.Drawing.Point(123, 228);
            this.I5.Name = "I5";
            this.I5.Size = new System.Drawing.Size(15, 14);
            this.I5.TabIndex = 195;
            this.I5.UseVisualStyleBackColor = true;
            // 
            // I4
            // 
            this.I4.AutoSize = true;
            this.I4.Location = new System.Drawing.Point(102, 228);
            this.I4.Name = "I4";
            this.I4.Size = new System.Drawing.Size(15, 14);
            this.I4.TabIndex = 194;
            this.I4.UseVisualStyleBackColor = true;
            // 
            // I3
            // 
            this.I3.AutoSize = true;
            this.I3.Location = new System.Drawing.Point(81, 228);
            this.I3.Name = "I3";
            this.I3.Size = new System.Drawing.Size(15, 14);
            this.I3.TabIndex = 193;
            this.I3.UseVisualStyleBackColor = true;
            // 
            // I2
            // 
            this.I2.AutoSize = true;
            this.I2.Location = new System.Drawing.Point(60, 228);
            this.I2.Name = "I2";
            this.I2.Size = new System.Drawing.Size(15, 14);
            this.I2.TabIndex = 192;
            this.I2.UseVisualStyleBackColor = true;
            // 
            // I1
            // 
            this.I1.AutoSize = true;
            this.I1.Location = new System.Drawing.Point(40, 228);
            this.I1.Name = "I1";
            this.I1.Size = new System.Drawing.Size(15, 14);
            this.I1.TabIndex = 191;
            this.I1.UseVisualStyleBackColor = true;
            // 
            // H10
            // 
            this.H10.AutoSize = true;
            this.H10.Location = new System.Drawing.Point(256, 208);
            this.H10.Name = "H10";
            this.H10.Size = new System.Drawing.Size(15, 14);
            this.H10.TabIndex = 190;
            this.H10.UseVisualStyleBackColor = true;
            // 
            // H9
            // 
            this.H9.AutoSize = true;
            this.H9.Location = new System.Drawing.Point(235, 208);
            this.H9.Name = "H9";
            this.H9.Size = new System.Drawing.Size(15, 14);
            this.H9.TabIndex = 189;
            this.H9.UseVisualStyleBackColor = true;
            // 
            // H8
            // 
            this.H8.AutoSize = true;
            this.H8.Location = new System.Drawing.Point(214, 208);
            this.H8.Name = "H8";
            this.H8.Size = new System.Drawing.Size(15, 14);
            this.H8.TabIndex = 188;
            this.H8.UseVisualStyleBackColor = true;
            // 
            // H7
            // 
            this.H7.AutoSize = true;
            this.H7.Location = new System.Drawing.Point(193, 208);
            this.H7.Name = "H7";
            this.H7.Size = new System.Drawing.Size(15, 14);
            this.H7.TabIndex = 187;
            this.H7.UseVisualStyleBackColor = true;
            // 
            // H6
            // 
            this.H6.AutoSize = true;
            this.H6.Location = new System.Drawing.Point(173, 208);
            this.H6.Name = "H6";
            this.H6.Size = new System.Drawing.Size(15, 14);
            this.H6.TabIndex = 186;
            this.H6.UseVisualStyleBackColor = true;
            // 
            // H5
            // 
            this.H5.AutoSize = true;
            this.H5.Location = new System.Drawing.Point(123, 208);
            this.H5.Name = "H5";
            this.H5.Size = new System.Drawing.Size(15, 14);
            this.H5.TabIndex = 185;
            this.H5.UseVisualStyleBackColor = true;
            // 
            // H4
            // 
            this.H4.AutoSize = true;
            this.H4.Location = new System.Drawing.Point(102, 208);
            this.H4.Name = "H4";
            this.H4.Size = new System.Drawing.Size(15, 14);
            this.H4.TabIndex = 184;
            this.H4.UseVisualStyleBackColor = true;
            // 
            // H3
            // 
            this.H3.AutoSize = true;
            this.H3.Location = new System.Drawing.Point(81, 208);
            this.H3.Name = "H3";
            this.H3.Size = new System.Drawing.Size(15, 14);
            this.H3.TabIndex = 183;
            this.H3.UseVisualStyleBackColor = true;
            // 
            // H2
            // 
            this.H2.AutoSize = true;
            this.H2.Location = new System.Drawing.Point(60, 208);
            this.H2.Name = "H2";
            this.H2.Size = new System.Drawing.Size(15, 14);
            this.H2.TabIndex = 182;
            this.H2.UseVisualStyleBackColor = true;
            // 
            // H1
            // 
            this.H1.AutoSize = true;
            this.H1.Location = new System.Drawing.Point(40, 208);
            this.H1.Name = "H1";
            this.H1.Size = new System.Drawing.Size(15, 14);
            this.H1.TabIndex = 181;
            this.H1.UseVisualStyleBackColor = true;
            // 
            // G10
            // 
            this.G10.AutoSize = true;
            this.G10.Location = new System.Drawing.Point(256, 188);
            this.G10.Name = "G10";
            this.G10.Size = new System.Drawing.Size(15, 14);
            this.G10.TabIndex = 180;
            this.G10.UseVisualStyleBackColor = true;
            // 
            // G9
            // 
            this.G9.AutoSize = true;
            this.G9.Location = new System.Drawing.Point(235, 188);
            this.G9.Name = "G9";
            this.G9.Size = new System.Drawing.Size(15, 14);
            this.G9.TabIndex = 179;
            this.G9.UseVisualStyleBackColor = true;
            // 
            // G8
            // 
            this.G8.AutoSize = true;
            this.G8.Location = new System.Drawing.Point(214, 188);
            this.G8.Name = "G8";
            this.G8.Size = new System.Drawing.Size(15, 14);
            this.G8.TabIndex = 178;
            this.G8.UseVisualStyleBackColor = true;
            // 
            // G7
            // 
            this.G7.AutoSize = true;
            this.G7.Location = new System.Drawing.Point(193, 188);
            this.G7.Name = "G7";
            this.G7.Size = new System.Drawing.Size(15, 14);
            this.G7.TabIndex = 177;
            this.G7.UseVisualStyleBackColor = true;
            // 
            // G6
            // 
            this.G6.AutoSize = true;
            this.G6.Location = new System.Drawing.Point(173, 188);
            this.G6.Name = "G6";
            this.G6.Size = new System.Drawing.Size(15, 14);
            this.G6.TabIndex = 176;
            this.G6.UseVisualStyleBackColor = true;
            // 
            // G5
            // 
            this.G5.AutoSize = true;
            this.G5.Location = new System.Drawing.Point(123, 188);
            this.G5.Name = "G5";
            this.G5.Size = new System.Drawing.Size(15, 14);
            this.G5.TabIndex = 175;
            this.G5.UseVisualStyleBackColor = true;
            // 
            // G4
            // 
            this.G4.AutoSize = true;
            this.G4.Location = new System.Drawing.Point(102, 188);
            this.G4.Name = "G4";
            this.G4.Size = new System.Drawing.Size(15, 14);
            this.G4.TabIndex = 174;
            this.G4.UseVisualStyleBackColor = true;
            // 
            // G3
            // 
            this.G3.AutoSize = true;
            this.G3.Location = new System.Drawing.Point(81, 188);
            this.G3.Name = "G3";
            this.G3.Size = new System.Drawing.Size(15, 14);
            this.G3.TabIndex = 173;
            this.G3.UseVisualStyleBackColor = true;
            // 
            // G2
            // 
            this.G2.AutoSize = true;
            this.G2.Location = new System.Drawing.Point(60, 188);
            this.G2.Name = "G2";
            this.G2.Size = new System.Drawing.Size(15, 14);
            this.G2.TabIndex = 172;
            this.G2.UseVisualStyleBackColor = true;
            // 
            // G1
            // 
            this.G1.AutoSize = true;
            this.G1.Location = new System.Drawing.Point(40, 188);
            this.G1.Name = "G1";
            this.G1.Size = new System.Drawing.Size(15, 14);
            this.G1.TabIndex = 171;
            this.G1.UseVisualStyleBackColor = true;
            // 
            // F10
            // 
            this.F10.AutoSize = true;
            this.F10.Location = new System.Drawing.Point(256, 168);
            this.F10.Name = "F10";
            this.F10.Size = new System.Drawing.Size(15, 14);
            this.F10.TabIndex = 170;
            this.F10.UseVisualStyleBackColor = true;
            // 
            // F9
            // 
            this.F9.AutoSize = true;
            this.F9.Location = new System.Drawing.Point(235, 168);
            this.F9.Name = "F9";
            this.F9.Size = new System.Drawing.Size(15, 14);
            this.F9.TabIndex = 169;
            this.F9.UseVisualStyleBackColor = true;
            // 
            // F8
            // 
            this.F8.AutoSize = true;
            this.F8.Location = new System.Drawing.Point(214, 168);
            this.F8.Name = "F8";
            this.F8.Size = new System.Drawing.Size(15, 14);
            this.F8.TabIndex = 168;
            this.F8.UseVisualStyleBackColor = true;
            // 
            // F7
            // 
            this.F7.AutoSize = true;
            this.F7.Location = new System.Drawing.Point(193, 168);
            this.F7.Name = "F7";
            this.F7.Size = new System.Drawing.Size(15, 14);
            this.F7.TabIndex = 167;
            this.F7.UseVisualStyleBackColor = true;
            // 
            // F6
            // 
            this.F6.AutoSize = true;
            this.F6.Location = new System.Drawing.Point(173, 168);
            this.F6.Name = "F6";
            this.F6.Size = new System.Drawing.Size(15, 14);
            this.F6.TabIndex = 166;
            this.F6.UseVisualStyleBackColor = true;
            // 
            // F5
            // 
            this.F5.AutoSize = true;
            this.F5.Location = new System.Drawing.Point(123, 168);
            this.F5.Name = "F5";
            this.F5.Size = new System.Drawing.Size(15, 14);
            this.F5.TabIndex = 165;
            this.F5.UseVisualStyleBackColor = true;
            // 
            // F4
            // 
            this.F4.AutoSize = true;
            this.F4.Location = new System.Drawing.Point(102, 168);
            this.F4.Name = "F4";
            this.F4.Size = new System.Drawing.Size(15, 14);
            this.F4.TabIndex = 164;
            this.F4.UseVisualStyleBackColor = true;
            // 
            // F3
            // 
            this.F3.AutoSize = true;
            this.F3.Location = new System.Drawing.Point(81, 168);
            this.F3.Name = "F3";
            this.F3.Size = new System.Drawing.Size(15, 14);
            this.F3.TabIndex = 163;
            this.F3.UseVisualStyleBackColor = true;
            // 
            // F2
            // 
            this.F2.AutoSize = true;
            this.F2.Location = new System.Drawing.Point(60, 168);
            this.F2.Name = "F2";
            this.F2.Size = new System.Drawing.Size(15, 14);
            this.F2.TabIndex = 162;
            this.F2.UseVisualStyleBackColor = true;
            // 
            // F1
            // 
            this.F1.AutoSize = true;
            this.F1.Location = new System.Drawing.Point(40, 168);
            this.F1.Name = "F1";
            this.F1.Size = new System.Drawing.Size(15, 14);
            this.F1.TabIndex = 161;
            this.F1.UseVisualStyleBackColor = true;
            // 
            // E10
            // 
            this.E10.AutoSize = true;
            this.E10.Location = new System.Drawing.Point(256, 148);
            this.E10.Name = "E10";
            this.E10.Size = new System.Drawing.Size(15, 14);
            this.E10.TabIndex = 160;
            this.E10.UseVisualStyleBackColor = true;
            // 
            // E9
            // 
            this.E9.AutoSize = true;
            this.E9.Location = new System.Drawing.Point(235, 148);
            this.E9.Name = "E9";
            this.E9.Size = new System.Drawing.Size(15, 14);
            this.E9.TabIndex = 159;
            this.E9.UseVisualStyleBackColor = true;
            // 
            // E8
            // 
            this.E8.AutoSize = true;
            this.E8.Location = new System.Drawing.Point(214, 148);
            this.E8.Name = "E8";
            this.E8.Size = new System.Drawing.Size(15, 14);
            this.E8.TabIndex = 158;
            this.E8.UseVisualStyleBackColor = true;
            // 
            // E7
            // 
            this.E7.AutoSize = true;
            this.E7.Location = new System.Drawing.Point(193, 148);
            this.E7.Name = "E7";
            this.E7.Size = new System.Drawing.Size(15, 14);
            this.E7.TabIndex = 157;
            this.E7.UseVisualStyleBackColor = true;
            // 
            // E6
            // 
            this.E6.AutoSize = true;
            this.E6.Location = new System.Drawing.Point(173, 148);
            this.E6.Name = "E6";
            this.E6.Size = new System.Drawing.Size(15, 14);
            this.E6.TabIndex = 156;
            this.E6.UseVisualStyleBackColor = true;
            // 
            // E5
            // 
            this.E5.AutoSize = true;
            this.E5.Location = new System.Drawing.Point(123, 148);
            this.E5.Name = "E5";
            this.E5.Size = new System.Drawing.Size(15, 14);
            this.E5.TabIndex = 155;
            this.E5.UseVisualStyleBackColor = true;
            // 
            // E4
            // 
            this.E4.AutoSize = true;
            this.E4.Location = new System.Drawing.Point(102, 148);
            this.E4.Name = "E4";
            this.E4.Size = new System.Drawing.Size(15, 14);
            this.E4.TabIndex = 154;
            this.E4.UseVisualStyleBackColor = true;
            // 
            // E3
            // 
            this.E3.AutoSize = true;
            this.E3.Location = new System.Drawing.Point(81, 148);
            this.E3.Name = "E3";
            this.E3.Size = new System.Drawing.Size(15, 14);
            this.E3.TabIndex = 153;
            this.E3.UseVisualStyleBackColor = true;
            // 
            // E2
            // 
            this.E2.AutoSize = true;
            this.E2.Location = new System.Drawing.Point(60, 148);
            this.E2.Name = "E2";
            this.E2.Size = new System.Drawing.Size(15, 14);
            this.E2.TabIndex = 152;
            this.E2.UseVisualStyleBackColor = true;
            // 
            // E1
            // 
            this.E1.AutoSize = true;
            this.E1.Location = new System.Drawing.Point(40, 148);
            this.E1.Name = "E1";
            this.E1.Size = new System.Drawing.Size(15, 14);
            this.E1.TabIndex = 151;
            this.E1.UseVisualStyleBackColor = true;
            // 
            // D10
            // 
            this.D10.AutoSize = true;
            this.D10.Location = new System.Drawing.Point(256, 128);
            this.D10.Name = "D10";
            this.D10.Size = new System.Drawing.Size(15, 14);
            this.D10.TabIndex = 150;
            this.D10.UseVisualStyleBackColor = true;
            // 
            // D9
            // 
            this.D9.AutoSize = true;
            this.D9.Location = new System.Drawing.Point(235, 128);
            this.D9.Name = "D9";
            this.D9.Size = new System.Drawing.Size(15, 14);
            this.D9.TabIndex = 149;
            this.D9.UseVisualStyleBackColor = true;
            // 
            // D8
            // 
            this.D8.AutoSize = true;
            this.D8.Location = new System.Drawing.Point(214, 128);
            this.D8.Name = "D8";
            this.D8.Size = new System.Drawing.Size(15, 14);
            this.D8.TabIndex = 148;
            this.D8.UseVisualStyleBackColor = true;
            // 
            // D7
            // 
            this.D7.AutoSize = true;
            this.D7.Location = new System.Drawing.Point(193, 128);
            this.D7.Name = "D7";
            this.D7.Size = new System.Drawing.Size(15, 14);
            this.D7.TabIndex = 147;
            this.D7.UseVisualStyleBackColor = true;
            // 
            // D6
            // 
            this.D6.AutoSize = true;
            this.D6.Location = new System.Drawing.Point(173, 128);
            this.D6.Name = "D6";
            this.D6.Size = new System.Drawing.Size(15, 14);
            this.D6.TabIndex = 146;
            this.D6.UseVisualStyleBackColor = true;
            // 
            // D5
            // 
            this.D5.AutoSize = true;
            this.D5.Location = new System.Drawing.Point(123, 128);
            this.D5.Name = "D5";
            this.D5.Size = new System.Drawing.Size(15, 14);
            this.D5.TabIndex = 145;
            this.D5.UseVisualStyleBackColor = true;
            // 
            // D4
            // 
            this.D4.AutoSize = true;
            this.D4.Location = new System.Drawing.Point(102, 128);
            this.D4.Name = "D4";
            this.D4.Size = new System.Drawing.Size(15, 14);
            this.D4.TabIndex = 144;
            this.D4.UseVisualStyleBackColor = true;
            // 
            // D3
            // 
            this.D3.AutoSize = true;
            this.D3.Location = new System.Drawing.Point(81, 128);
            this.D3.Name = "D3";
            this.D3.Size = new System.Drawing.Size(15, 14);
            this.D3.TabIndex = 143;
            this.D3.UseVisualStyleBackColor = true;
            // 
            // D2
            // 
            this.D2.AutoSize = true;
            this.D2.Location = new System.Drawing.Point(60, 128);
            this.D2.Name = "D2";
            this.D2.Size = new System.Drawing.Size(15, 14);
            this.D2.TabIndex = 142;
            this.D2.UseVisualStyleBackColor = true;
            // 
            // D1
            // 
            this.D1.AutoSize = true;
            this.D1.Location = new System.Drawing.Point(40, 128);
            this.D1.Name = "D1";
            this.D1.Size = new System.Drawing.Size(15, 14);
            this.D1.TabIndex = 141;
            this.D1.UseVisualStyleBackColor = true;
            // 
            // A10
            // 
            this.A10.AutoSize = true;
            this.A10.Location = new System.Drawing.Point(256, 68);
            this.A10.Name = "A10";
            this.A10.Size = new System.Drawing.Size(15, 14);
            this.A10.TabIndex = 140;
            this.A10.UseVisualStyleBackColor = true;
            // 
            // A9
            // 
            this.A9.AutoSize = true;
            this.A9.Location = new System.Drawing.Point(235, 68);
            this.A9.Name = "A9";
            this.A9.Size = new System.Drawing.Size(15, 14);
            this.A9.TabIndex = 139;
            this.A9.UseVisualStyleBackColor = true;
            // 
            // A8
            // 
            this.A8.AutoSize = true;
            this.A8.Location = new System.Drawing.Point(214, 68);
            this.A8.Name = "A8";
            this.A8.Size = new System.Drawing.Size(15, 14);
            this.A8.TabIndex = 138;
            this.A8.UseVisualStyleBackColor = true;
            // 
            // A7
            // 
            this.A7.AutoSize = true;
            this.A7.Location = new System.Drawing.Point(193, 68);
            this.A7.Name = "A7";
            this.A7.Size = new System.Drawing.Size(15, 14);
            this.A7.TabIndex = 137;
            this.A7.UseVisualStyleBackColor = true;
            // 
            // A6
            // 
            this.A6.AutoSize = true;
            this.A6.Location = new System.Drawing.Point(173, 68);
            this.A6.Name = "A6";
            this.A6.Size = new System.Drawing.Size(15, 14);
            this.A6.TabIndex = 136;
            this.A6.UseVisualStyleBackColor = true;
            // 
            // A5
            // 
            this.A5.AutoSize = true;
            this.A5.Location = new System.Drawing.Point(123, 68);
            this.A5.Name = "A5";
            this.A5.Size = new System.Drawing.Size(15, 14);
            this.A5.TabIndex = 135;
            this.A5.UseVisualStyleBackColor = true;
            // 
            // A4
            // 
            this.A4.AutoSize = true;
            this.A4.Location = new System.Drawing.Point(102, 68);
            this.A4.Name = "A4";
            this.A4.Size = new System.Drawing.Size(15, 14);
            this.A4.TabIndex = 134;
            this.A4.UseVisualStyleBackColor = true;
            // 
            // A3
            // 
            this.A3.AutoSize = true;
            this.A3.Location = new System.Drawing.Point(81, 68);
            this.A3.Name = "A3";
            this.A3.Size = new System.Drawing.Size(15, 14);
            this.A3.TabIndex = 133;
            this.A3.UseVisualStyleBackColor = true;
            // 
            // A2
            // 
            this.A2.AutoSize = true;
            this.A2.Location = new System.Drawing.Point(60, 68);
            this.A2.Name = "A2";
            this.A2.Size = new System.Drawing.Size(15, 14);
            this.A2.TabIndex = 132;
            this.A2.UseVisualStyleBackColor = true;
            // 
            // A1
            // 
            this.A1.AutoSize = true;
            this.A1.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.A1.Location = new System.Drawing.Point(40, 68);
            this.A1.Name = "A1";
            this.A1.Size = new System.Drawing.Size(15, 14);
            this.A1.TabIndex = 131;
            this.A1.UseVisualStyleBackColor = false;
            // 
            // C10
            // 
            this.C10.AutoSize = true;
            this.C10.Location = new System.Drawing.Point(256, 108);
            this.C10.Name = "C10";
            this.C10.Size = new System.Drawing.Size(15, 14);
            this.C10.TabIndex = 130;
            this.C10.UseVisualStyleBackColor = true;
            // 
            // C9
            // 
            this.C9.AutoSize = true;
            this.C9.Location = new System.Drawing.Point(235, 108);
            this.C9.Name = "C9";
            this.C9.Size = new System.Drawing.Size(15, 14);
            this.C9.TabIndex = 129;
            this.C9.UseVisualStyleBackColor = true;
            // 
            // C8
            // 
            this.C8.AutoSize = true;
            this.C8.Location = new System.Drawing.Point(214, 108);
            this.C8.Name = "C8";
            this.C8.Size = new System.Drawing.Size(15, 14);
            this.C8.TabIndex = 128;
            this.C8.UseVisualStyleBackColor = true;
            // 
            // C7
            // 
            this.C7.AutoSize = true;
            this.C7.Location = new System.Drawing.Point(193, 108);
            this.C7.Name = "C7";
            this.C7.Size = new System.Drawing.Size(15, 14);
            this.C7.TabIndex = 127;
            this.C7.UseVisualStyleBackColor = true;
            // 
            // C6
            // 
            this.C6.AutoSize = true;
            this.C6.Location = new System.Drawing.Point(173, 108);
            this.C6.Name = "C6";
            this.C6.Size = new System.Drawing.Size(15, 14);
            this.C6.TabIndex = 126;
            this.C6.UseVisualStyleBackColor = true;
            // 
            // C5
            // 
            this.C5.AutoSize = true;
            this.C5.Location = new System.Drawing.Point(123, 108);
            this.C5.Name = "C5";
            this.C5.Size = new System.Drawing.Size(15, 14);
            this.C5.TabIndex = 125;
            this.C5.UseVisualStyleBackColor = true;
            // 
            // C4
            // 
            this.C4.AutoSize = true;
            this.C4.Location = new System.Drawing.Point(102, 108);
            this.C4.Name = "C4";
            this.C4.Size = new System.Drawing.Size(15, 14);
            this.C4.TabIndex = 124;
            this.C4.UseVisualStyleBackColor = true;
            // 
            // C3
            // 
            this.C3.AutoSize = true;
            this.C3.Location = new System.Drawing.Point(81, 108);
            this.C3.Name = "C3";
            this.C3.Size = new System.Drawing.Size(15, 14);
            this.C3.TabIndex = 123;
            this.C3.UseVisualStyleBackColor = true;
            // 
            // C2
            // 
            this.C2.AutoSize = true;
            this.C2.Location = new System.Drawing.Point(60, 108);
            this.C2.Name = "C2";
            this.C2.Size = new System.Drawing.Size(15, 14);
            this.C2.TabIndex = 122;
            this.C2.UseVisualStyleBackColor = true;
            // 
            // C1
            // 
            this.C1.AutoSize = true;
            this.C1.Location = new System.Drawing.Point(40, 108);
            this.C1.Name = "C1";
            this.C1.Size = new System.Drawing.Size(15, 14);
            this.C1.TabIndex = 121;
            this.C1.UseVisualStyleBackColor = true;
            // 
            // B10
            // 
            this.B10.AutoSize = true;
            this.B10.Location = new System.Drawing.Point(256, 88);
            this.B10.Name = "B10";
            this.B10.Size = new System.Drawing.Size(15, 14);
            this.B10.TabIndex = 120;
            this.B10.UseVisualStyleBackColor = true;
            // 
            // B9
            // 
            this.B9.AutoSize = true;
            this.B9.Location = new System.Drawing.Point(235, 88);
            this.B9.Name = "B9";
            this.B9.Size = new System.Drawing.Size(15, 14);
            this.B9.TabIndex = 119;
            this.B9.UseVisualStyleBackColor = true;
            // 
            // B8
            // 
            this.B8.AutoSize = true;
            this.B8.Location = new System.Drawing.Point(214, 88);
            this.B8.Name = "B8";
            this.B8.Size = new System.Drawing.Size(15, 14);
            this.B8.TabIndex = 118;
            this.B8.UseVisualStyleBackColor = true;
            // 
            // B7
            // 
            this.B7.AutoSize = true;
            this.B7.Location = new System.Drawing.Point(193, 88);
            this.B7.Name = "B7";
            this.B7.Size = new System.Drawing.Size(15, 14);
            this.B7.TabIndex = 117;
            this.B7.UseVisualStyleBackColor = true;
            
            // 
            // B6
            // 
            this.B6.AutoSize = true;
            this.B6.Location = new System.Drawing.Point(173, 88);
            this.B6.Name = "B6";
            this.B6.Size = new System.Drawing.Size(15, 14);
            this.B6.TabIndex = 116;
            this.B6.UseVisualStyleBackColor = true;
            // 
            // B5
            // 
            this.B5.AutoSize = true;
            this.B5.Location = new System.Drawing.Point(123, 88);
            this.B5.Name = "B5";
            this.B5.Size = new System.Drawing.Size(15, 14);
            this.B5.TabIndex = 115;
            this.B5.UseVisualStyleBackColor = true;
            // 
            // B4
            // 
            this.B4.AutoSize = true;
            this.B4.Location = new System.Drawing.Point(102, 88);
            this.B4.Name = "B4";
            this.B4.Size = new System.Drawing.Size(15, 14);
            this.B4.TabIndex = 114;
            this.B4.UseVisualStyleBackColor = true;
            // 
            // B3
            // 
            this.B3.AutoSize = true;
            this.B3.Location = new System.Drawing.Point(81, 88);
            this.B3.Name = "B3";
            this.B3.Size = new System.Drawing.Size(15, 14);
            this.B3.TabIndex = 113;
            this.B3.UseVisualStyleBackColor = true;
            // 
            // B2
            // 
            this.B2.AutoSize = true;
            this.B2.Location = new System.Drawing.Point(60, 88);
            this.B2.Name = "B2";
            this.B2.Size = new System.Drawing.Size(15, 14);
            this.B2.TabIndex = 112;
            this.B2.UseVisualStyleBackColor = true;
            // 
            // B1
            // 
            this.B1.AutoSize = true;
            this.B1.Location = new System.Drawing.Point(40, 88);
            this.B1.Name = "B1";
            this.B1.Size = new System.Drawing.Size(15, 14);
            this.B1.TabIndex = 111;
            this.B1.UseVisualStyleBackColor = true;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(12, 68);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(14, 13);
            this.label5.TabIndex = 211;
            this.label5.Text = "A";
            
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(12, 88);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(14, 13);
            this.label6.TabIndex = 212;
            this.label6.Text = "B";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(12, 108);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(14, 13);
            this.label7.TabIndex = 213;
            this.label7.Text = "C";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(12, 128);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(15, 13);
            this.label8.TabIndex = 214;
            this.label8.Text = "D";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(12, 148);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(14, 13);
            this.label9.TabIndex = 215;
            this.label9.Text = "E";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(12, 168);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(13, 13);
            this.label10.TabIndex = 216;
            this.label10.Text = "F";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(12, 188);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(15, 13);
            this.label11.TabIndex = 217;
            this.label11.Text = "G";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(12, 208);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(15, 13);
            this.label12.TabIndex = 218;
            this.label12.Text = "H";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(12, 228);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(10, 13);
            this.label13.TabIndex = 219;
            this.label13.Text = "I";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(12, 248);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(12, 13);
            this.label14.TabIndex = 220;
            this.label14.Text = "J";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(41, 52);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(13, 13);
            this.label15.TabIndex = 221;
            this.label15.Text = "1";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(61, 52);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(13, 13);
            this.label16.TabIndex = 222;
            this.label16.Text = "2";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(82, 52);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(13, 13);
            this.label17.TabIndex = 223;
            this.label17.Text = "3";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(102, 52);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(13, 13);
            this.label18.TabIndex = 224;
            this.label18.Text = "4";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(124, 52);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(13, 13);
            this.label19.TabIndex = 225;
            this.label19.Text = "5";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(174, 52);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(13, 13);
            this.label20.TabIndex = 226;
            this.label20.Text = "6";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(194, 52);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(13, 13);
            this.label21.TabIndex = 227;
            this.label21.Text = "7";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(215, 52);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(13, 13);
            this.label22.TabIndex = 228;
            this.label22.Text = "8";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(236, 52);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(13, 13);
            this.label23.TabIndex = 229;
            this.label23.Text = "9";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(252, 52);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(19, 13);
            this.label24.TabIndex = 230;
            this.label24.Text = "10";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(576, 297);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.J10);
            this.Controls.Add(this.J9);
            this.Controls.Add(this.J8);
            this.Controls.Add(this.J7);
            this.Controls.Add(this.J6);
            this.Controls.Add(this.J5);
            this.Controls.Add(this.J4);
            this.Controls.Add(this.J3);
            this.Controls.Add(this.J2);
            this.Controls.Add(this.J1);
            this.Controls.Add(this.I10);
            this.Controls.Add(this.I9);
            this.Controls.Add(this.I8);
            this.Controls.Add(this.I7);
            this.Controls.Add(this.I6);
            this.Controls.Add(this.I5);
            this.Controls.Add(this.I4);
            this.Controls.Add(this.I3);
            this.Controls.Add(this.I2);
            this.Controls.Add(this.I1);
            this.Controls.Add(this.H10);
            this.Controls.Add(this.H9);
            this.Controls.Add(this.H8);
            this.Controls.Add(this.H7);
            this.Controls.Add(this.H6);
            this.Controls.Add(this.H5);
            this.Controls.Add(this.H4);
            this.Controls.Add(this.H3);
            this.Controls.Add(this.H2);
            this.Controls.Add(this.H1);
            this.Controls.Add(this.G10);
            this.Controls.Add(this.G9);
            this.Controls.Add(this.G8);
            this.Controls.Add(this.G7);
            this.Controls.Add(this.G6);
            this.Controls.Add(this.G5);
            this.Controls.Add(this.G4);
            this.Controls.Add(this.G3);
            this.Controls.Add(this.G2);
            this.Controls.Add(this.G1);
            this.Controls.Add(this.F10);
            this.Controls.Add(this.F9);
            this.Controls.Add(this.F8);
            this.Controls.Add(this.F7);
            this.Controls.Add(this.F6);
            this.Controls.Add(this.F5);
            this.Controls.Add(this.F4);
            this.Controls.Add(this.F3);
            this.Controls.Add(this.F2);
            this.Controls.Add(this.F1);
            this.Controls.Add(this.E10);
            this.Controls.Add(this.E9);
            this.Controls.Add(this.E8);
            this.Controls.Add(this.E7);
            this.Controls.Add(this.E6);
            this.Controls.Add(this.E5);
            this.Controls.Add(this.E4);
            this.Controls.Add(this.E3);
            this.Controls.Add(this.E2);
            this.Controls.Add(this.E1);
            this.Controls.Add(this.D10);
            this.Controls.Add(this.D9);
            this.Controls.Add(this.D8);
            this.Controls.Add(this.D7);
            this.Controls.Add(this.D6);
            this.Controls.Add(this.D5);
            this.Controls.Add(this.D4);
            this.Controls.Add(this.D3);
            this.Controls.Add(this.D2);
            this.Controls.Add(this.D1);
            this.Controls.Add(this.A10);
            this.Controls.Add(this.A9);
            this.Controls.Add(this.A8);
            this.Controls.Add(this.A7);
            this.Controls.Add(this.A6);
            this.Controls.Add(this.A5);
            this.Controls.Add(this.A4);
            this.Controls.Add(this.A3);
            this.Controls.Add(this.A2);
            this.Controls.Add(this.A1);
            this.Controls.Add(this.C10);
            this.Controls.Add(this.C9);
            this.Controls.Add(this.C8);
            this.Controls.Add(this.C7);
            this.Controls.Add(this.C6);
            this.Controls.Add(this.C5);
            this.Controls.Add(this.C4);
            this.Controls.Add(this.C3);
            this.Controls.Add(this.C2);
            this.Controls.Add(this.C1);
            this.Controls.Add(this.B10);
            this.Controls.Add(this.B9);
            this.Controls.Add(this.B8);
            this.Controls.Add(this.B7);
            this.Controls.Add(this.B6);
            this.Controls.Add(this.B5);
            this.Controls.Add(this.B4);
            this.Controls.Add(this.B3);
            this.Controls.Add(this.B2);
            this.Controls.Add(this.B1);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.textBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.CheckBox J10;
        private System.Windows.Forms.CheckBox J9;
        private System.Windows.Forms.CheckBox J8;
        private System.Windows.Forms.CheckBox J7;
        private System.Windows.Forms.CheckBox J6;
        private System.Windows.Forms.CheckBox J5;
        private System.Windows.Forms.CheckBox J4;
        private System.Windows.Forms.CheckBox J3;
        private System.Windows.Forms.CheckBox J2;
        private System.Windows.Forms.CheckBox J1;
        private System.Windows.Forms.CheckBox I10;
        private System.Windows.Forms.CheckBox I9;
        private System.Windows.Forms.CheckBox I8;
        private System.Windows.Forms.CheckBox I7;
        private System.Windows.Forms.CheckBox I6;
        private System.Windows.Forms.CheckBox I5;
        private System.Windows.Forms.CheckBox I4;
        private System.Windows.Forms.CheckBox I3;
        private System.Windows.Forms.CheckBox I2;
        private System.Windows.Forms.CheckBox I1;
        private System.Windows.Forms.CheckBox H10;
        private System.Windows.Forms.CheckBox H9;
        private System.Windows.Forms.CheckBox H8;
        private System.Windows.Forms.CheckBox H7;
        private System.Windows.Forms.CheckBox H6;
        private System.Windows.Forms.CheckBox H5;
        private System.Windows.Forms.CheckBox H4;
        private System.Windows.Forms.CheckBox H3;
        private System.Windows.Forms.CheckBox H2;
        private System.Windows.Forms.CheckBox H1;
        private System.Windows.Forms.CheckBox G10;
        private System.Windows.Forms.CheckBox G9;
        private System.Windows.Forms.CheckBox G8;
        private System.Windows.Forms.CheckBox G7;
        private System.Windows.Forms.CheckBox G6;
        private System.Windows.Forms.CheckBox G5;
        private System.Windows.Forms.CheckBox G4;
        private System.Windows.Forms.CheckBox G3;
        private System.Windows.Forms.CheckBox G2;
        private System.Windows.Forms.CheckBox G1;
        private System.Windows.Forms.CheckBox F10;
        private System.Windows.Forms.CheckBox F9;
        private System.Windows.Forms.CheckBox F8;
        private System.Windows.Forms.CheckBox F7;
        private System.Windows.Forms.CheckBox F6;
        private System.Windows.Forms.CheckBox F5;
        private System.Windows.Forms.CheckBox F4;
        private System.Windows.Forms.CheckBox F3;
        private System.Windows.Forms.CheckBox F2;
        private System.Windows.Forms.CheckBox F1;
        private System.Windows.Forms.CheckBox E10;
        private System.Windows.Forms.CheckBox E9;
        private System.Windows.Forms.CheckBox E8;
        private System.Windows.Forms.CheckBox E7;
        private System.Windows.Forms.CheckBox E6;
        private System.Windows.Forms.CheckBox E5;
        private System.Windows.Forms.CheckBox E4;
        private System.Windows.Forms.CheckBox E3;
        private System.Windows.Forms.CheckBox E2;
        private System.Windows.Forms.CheckBox E1;
        private System.Windows.Forms.CheckBox D10;
        private System.Windows.Forms.CheckBox D9;
        private System.Windows.Forms.CheckBox D8;
        private System.Windows.Forms.CheckBox D7;
        private System.Windows.Forms.CheckBox D6;
        private System.Windows.Forms.CheckBox D5;
        private System.Windows.Forms.CheckBox D4;
        private System.Windows.Forms.CheckBox D3;
        private System.Windows.Forms.CheckBox D2;
        private System.Windows.Forms.CheckBox D1;
        private System.Windows.Forms.CheckBox A10;
        private System.Windows.Forms.CheckBox A9;
        private System.Windows.Forms.CheckBox A8;
        private System.Windows.Forms.CheckBox A7;
        private System.Windows.Forms.CheckBox A6;
        private System.Windows.Forms.CheckBox A5;
        private System.Windows.Forms.CheckBox A4;
        private System.Windows.Forms.CheckBox A3;
        private System.Windows.Forms.CheckBox A2;
        private System.Windows.Forms.CheckBox A1;
        private System.Windows.Forms.CheckBox C10;
        private System.Windows.Forms.CheckBox C9;
        private System.Windows.Forms.CheckBox C8;
        private System.Windows.Forms.CheckBox C7;
        private System.Windows.Forms.CheckBox C6;
        private System.Windows.Forms.CheckBox C5;
        private System.Windows.Forms.CheckBox C4;
        private System.Windows.Forms.CheckBox C3;
        private System.Windows.Forms.CheckBox C2;
        private System.Windows.Forms.CheckBox C1;
        private System.Windows.Forms.CheckBox B10;
        private System.Windows.Forms.CheckBox B9;
        private System.Windows.Forms.CheckBox B8;
        private System.Windows.Forms.CheckBox B7;
        private System.Windows.Forms.CheckBox B6;
        private System.Windows.Forms.CheckBox B5;
        private System.Windows.Forms.CheckBox B4;
        private System.Windows.Forms.CheckBox B3;
        private System.Windows.Forms.CheckBox B2;
        private System.Windows.Forms.CheckBox B1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
    }
}


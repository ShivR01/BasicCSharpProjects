﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace WeatherAppMVC.Controllers
{
    public class UsersController : Controller
    {
        WeatherAppEntities db = new WeatherAppEntities();
        // GET: Users
        public ActionResult ForeCasts()
        {
            var forecasts = db.Forecasts;
            return View(forecasts.ToList());
        }

        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Login()
        {
            if (Session["Error messsage"] == null)
            {
                ViewBag.Error = Session["Error message"] as string;
            }
            return View();

        }
        [HttpPost]
        public ActionResult Login(string tbUsername, string tbPassword)
        {
            bool found = false;
            foreach (Users u in db.Users)
            {
                if (tbUsername.Equals(u.Username) && (tbPassword.Equals(tbPassword)))
                {
                    found = true;
                    Session["Username"] = tbUsername;
                    return RedirectToAction("FavCity", "Favs");
                }
            }
            if (!found)
            {
                ViewBag.Error = ("Incorrect password or username");

            }
            return View();
        }

        public ActionResult Success()
        {
            if (Session["Username"] == null)
            {
                Session["Error message"] = "You need to login first";
                return RedirectToAction("Login");
            }
            else
            {
                return View();
            }
        }
    }
}
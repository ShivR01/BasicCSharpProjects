﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using WeatherAppMVC;

namespace WeatherAppMVC.Controllers
{
    public class FavsController : Controller
    {
        private WeatherAppEntities db = new WeatherAppEntities();

        // GET: Favs
        public ActionResult FavCity()
        {
            if (Session["Username"] == null)
            {
                Session["Error message"] = "You need to login first";
                return RedirectToAction("Login", "Users");
            }
            else
            {
                var fav = db.Fav.Include(f => f.Cities).Include(f => f.Users);
                return View(fav.ToList());
            }

        }

        // GET: Favs/Details/5
        public ActionResult Details(int? id)
        {
            if (Session["Username"] == null)
            {
                Session["Error message"] = "You need to login first";
                return RedirectToAction("Login", "Users");
            }
            else
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }
                
                return RedirectToAction("ForeCasts", "Users");
            }
            
        }

        // GET: Favs/Create
        public ActionResult Create()
        {
            if (Session["Username"] == null)
            {
                Session["Error message"] = "You need to login first";
                return RedirectToAction("Login", "Users");
            }
            else
            {
                ViewBag.City = new SelectList(db.Cities, "City", "City");
                ViewBag.Username = new SelectList(db.Users, "Username", "Pass");
                return View();
            }
    
        }

        // POST: Favs/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "FavID,Username,City")] Fav fav)
        {
            if (ModelState.IsValid)
            {
                db.Fav.Add(fav);
                db.SaveChanges();
                return RedirectToAction("FavCity");
            }

            ViewBag.City = new SelectList(db.Cities, "City", "City", fav.City);
            ViewBag.Username = new SelectList(db.Users, "Username", "Pass", fav.Username);
            return View(fav);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}

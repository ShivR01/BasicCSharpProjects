﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using WeatherAppMVC;

namespace WeatherAppMVC.Controllers
{
    public class ForecastsController : Controller
    {
        private WeatherAppEntities db = new WeatherAppEntities();

        // GET: Forecasts
        public ActionResult ForecastList()
        {
            if (Session["Username"] == null)
            {
                Session["Error message"] = "You need to login first";
                return RedirectToAction("Login","Users");
            }
            else
            {
                var forecasts = db.Forecasts.Include(f => f.Cities);
                //return View(forecasts.ToList().Where(s => s.Cities.Equals(Session["Username"] as string)).OrderBy(s => s.Cities.City));
                return View(forecasts.ToList());
            }
        }

        // GET: Forecasts/Details/5
        public ActionResult Details(decimal id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Forecasts forecasts = db.Forecasts.Find(id);
            if (forecasts == null)
            {
                return HttpNotFound();
            }
            return View(forecasts);
        }

        // GET: Forecasts/Create
        public ActionResult Create()
        {
            ViewBag.City = new SelectList(db.Cities, "City", "City");
            return View();
        }

        // POST: Forecasts/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "FID,City,WeatherDate,MinTemp,MaxTemp,Prec,Humid,Wind")] Forecasts forecasts)
        {
            if (ModelState.IsValid)
            {
                db.Forecasts.Add(forecasts);
                db.SaveChanges();
                return RedirectToAction("ForecastList");
            }

            ViewBag.City = new SelectList(db.Cities, "City", "City", forecasts.City);
            return View(forecasts);
        }

        // GET: Forecasts/Edit/5
        public ActionResult Edit(decimal id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Forecasts forecasts = db.Forecasts.Find(id);
            if (forecasts == null)
            {
                return HttpNotFound();
            }
            ViewBag.City = new SelectList(db.Cities, "City", "City", forecasts.City);
            return View(forecasts);
        }

        // POST: Forecasts/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "FID,City,WeatherDate,MinTemp,MaxTemp,Prec,Humid,Wind")] Forecasts forecasts)
        {
            if (ModelState.IsValid)
            {
                db.Entry(forecasts).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("ForecastList");
            }
            ViewBag.City = new SelectList(db.Cities, "City", "City", forecasts.City);
            return View(forecasts);
        }

        // GET: Forecasts/Delete/5
        public ActionResult Delete(decimal id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Forecasts forecasts = db.Forecasts.Find(id);
            if (forecasts == null)
            {
                return HttpNotFound();
            }
            return View(forecasts);
        }

        // POST: Forecasts/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(decimal id)
        {
            Forecasts forecasts = db.Forecasts.Find(id);
            db.Forecasts.Remove(forecasts);
            db.SaveChanges();
            return RedirectToAction("ForecastList");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}

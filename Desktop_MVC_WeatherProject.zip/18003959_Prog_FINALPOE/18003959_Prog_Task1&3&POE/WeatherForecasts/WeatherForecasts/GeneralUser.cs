﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WeatherForecasts
{
    public partial class GeneralUser : Form
    {
        int dateDiff;
        DateTime newdate;
        List<String> cities = new List<String>() { "Durban", "Cape Town", "Johannesburg", "Pretoria" };
        List<WeatherVariables> genUser = new List<WeatherVariables>();
        WeatherVariables vari = new WeatherVariables();//Used for accessing variables from class
        List<WeatherVariables> highLow = new List<WeatherVariables>();//Used in finding highest and lowest
        List<String> FavUsers = new List<String>();
        List<String> FavCity = new List<String>();
        DateTime date;
        string user;
        public GeneralUser(string user1)
        {
            InitializeComponent();
            user = user1; 
        }

        private void GeneralUser_Load(object sender, EventArgs e)
        {
            lblUser.Text = "Report for " + user; //Changes label to display username of logged in general user
            cmbCity.Visible = false;
            btnAddCity.Visible = false;
            using (var f = new StreamReader("Stored.txt"))//Gets dummy values from text file Stored.txt
            {
                string line;
                while ((line = f.ReadLine()) != null)
                {
                    var parts = line.Split('#'); //splits lines seperated by delimiter
                    genUser.Add(new WeatherVariables(parts[0],Convert.ToDateTime(parts[1]), Convert.ToDouble(parts[2]), Convert.ToDouble(parts[3]), Convert.ToDouble(parts[4]), Convert.ToDouble(parts[5]), Convert.ToDouble(parts[6])));
                }
            }
            int flag = 999; 
            for (int i = 0; i < genUser.Count; i++) // adds new cities of forcasts to citites list
            {
                for (int l = 0; l < cities.Count; l++)
                {
                    if (genUser[i].City == cities[l])//Checks each city for a match, if not found the city will then be added to the list
                    {
                        flag = 0;
                    }
                    else {
                        flag = 1;
                        break;
                    }
                }
                if (flag == 0)
                {
                    cities.Add(genUser[i].City);//Adds cities to list
                }
            }
            //Above code adds new Cities (If any) besides Durban, Cape Town, Johannesburg, Pretoria
            foreach (var item in cities) //Adds cities into combo box
            {
                cmbCity.Items.Add(item);
            }
            try
            {
                using (SqlConnection con = new SqlConnection(Properties.Settings.Default.ConString))//Gets favourtie cities from database for displaying
                {
                    string sqlQuery = "Select * from Fav";
                    con.Open();
                    using (SqlCommand cmd = new SqlCommand(sqlQuery, con))
                    {
                        SqlDataReader dataReader = cmd.ExecuteReader();
                        while (dataReader.Read())
                        {
                            FavUsers.Add(dataReader.GetString(1));
                            FavCity.Add(dataReader.GetString(2));
                        }

                        dataReader.Close();
                        if (con.State == ConnectionState.Open)
                            con.Close();
                        cmd.Dispose();
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }
            for (int i = 0; i < FavUsers.Count; i++)
            {
                if (FavUsers[i] == user)
                {
                  rtbCitiesAdded.Text += FavCity[i]+"\n";
                  vari.AddCity.Add(FavCity[i]);
                }
            }
        }

        private void btnExit_Click(object sender, EventArgs e)//Exits app
        {
            if (MessageBox.Show("Are you sure want to exit?", "Weather App", MessageBoxButtons.OKCancel, MessageBoxIcon.Information) == DialogResult.OK)
            {
                Application.Exit();
            }
        }

        private void btnAddCity_Click(object sender, EventArgs e)
        {
            int flag = 99;
            for (int i = 0; i < vari.AddCity.Count; i++)//Checks if user selects city already in his/hers favourites
            {
                if (vari.AddCity[i] == cmbCity.SelectedItem + "")
                {
                    MessageBox.Show("City already added. Please select another city.");
                    flag = 1;
                    break;
                }
                else
                {
                    flag = 0;
                }
            }
            if (flag == 0)
            {
                vari.AddCity.Add(cmbCity.SelectedItem + "");
                MessageBox.Show("Favourite city added");

                rtbCitiesAdded.Clear();
                foreach (string s in vari.AddCity)           //re-displays all values in list of cities
                {
                    rtbCitiesAdded.Text += s + "\n";
                }
                Random rnd = new Random();
                double id = rnd.Next(4, 999);
                try
                {
                    using (SqlConnection con = new SqlConnection(Properties.Settings.Default.ConString))//Adds new favourite city to database
                    {
                        string sqlQuery = "Insert into Fav (FavID, Username, City) VALUES (@FavID, @Username, @City); ";
                        con.Open();
                        using (SqlCommand cmd = new SqlCommand(sqlQuery, con))
                        {
                            cmd.Parameters.AddWithValue("@FavID", id);
                            cmd.Parameters.AddWithValue("@Username", user);
                            cmd.Parameters.AddWithValue("@City", cmbCity.SelectedItem + "");
                            cmd.ExecuteNonQuery();

                            if (con.State == ConnectionState.Open)
                                con.Close();
                            MessageBox.Show("New city added successfully");
                        }
                    }
                }
                catch (Exception)
                {
                    throw;
                }
            }
        }

        private void btnGen_Click(object sender, EventArgs e)
        {
            GetHighLow();                                //recieves the highest and lowest values
            date = Convert.ToDateTime(dtpStart.Text);

            for (int l = 0; l < vari.AddCity.Count; l++)
            {
                for (int i = 0; i < dateDiff; i++) //increments on the range of days from the difference
                {
                    newdate = date.AddDays(i);     //adds 1 day 

                    for (int j = 0; j < genUser.Count; j++)
                    {
                        if ((genUser[j].City == (vari.AddCity[l]) && (genUser[j].Date == newdate)))//Checks values of selected city
                        {
                            createPanelLabel(vari.AddCity[l], vari.Panelnum[i], vari.PanelColumn[l], genUser[j].MinTemp, genUser[j].MaxTemp, genUser[j].Precipitation, genUser[j].Humidity, genUser[j].WindSpeed, newdate.ToString("ddd"));//Dynamically creates panels displaying weather forecasts
                        }
                    }
                }
            }
        }

        private void GetHighLow()
        {
            date = Convert.ToDateTime(dtpStart.Text);
            dateDiff = (Convert.ToDateTime(dtpEnd.Text) - Convert.ToDateTime(dtpStart.Text)).Days; //Gets the difference in days
            for (int i = 0; i < dateDiff; i++) //increments on the range of days from the difference
            {
                newdate = date.AddDays(i);
                for (int j = 0; j < genUser.Count; j++)
                {
                    for (int k = 0; k < vari.AddCity.Count; k++)//Checks for each city in addCity list
                    {
                        if ((genUser[j].City == (vari.AddCity[k])) && (genUser[j].Date == newdate))//Gets values of selected city
                        {
                            highLow.Add(new WeatherVariables(genUser[j].MinTemp, genUser[j].MaxTemp, genUser[j].Precipitation, genUser[j].Humidity, genUser[j].WindSpeed, newdate.ToString("ddd")));
                        }
                    }
                }
            }

            for (int i = 0; i < highLow.Count; i++)//Gets highest and lowest values
            {
                if (highLow[i].MinTemp <= vari.LowTemp)//Gets lowest temp
                {
                    vari.LowTemp = highLow[i].MinTemp;
                }

                if (highLow[i].MaxTemp >= vari.HighTemp)//Gets highest temp
                {
                    vari.HighTemp = highLow[i].MaxTemp;
                }

                if (highLow[i].Precipitation >= vari.HighPre)//Gets highest Precipitation
                {
                    vari.HighPre = highLow[i].Precipitation;
                }

                if (highLow[i].Humidity >= vari.HighHum)//Gets highest Humidity
                {
                    vari.HighHum = highLow[i].Humidity;
                }

                if (highLow[i].WindSpeed >= vari.HighWind)//Gets highest Wind speed
                {
                    vari.HighWind = highLow[i].WindSpeed;
                }
            }
        }
        private void createPanelLabel(string city, int pnlnum, int pnlcol, double minT, double maxT, double precep, double humid, double windSp, string wday) //Dyanmically creates panels for generating report
        {
            Panel panel = new Panel();
            Label cityName = new Label();
            Label day = new Label();
            Label min = new Label();
            Label max = new Label();
            Label pre = new Label();
            Label hum = new Label();
            Label wind = new Label();

            cityName.Location = new Point(3, 0);                            //Label for name if city
            cityName.Size = new Size(90, 13);
            cityName.Text = city;
            cityName.Font = new Font(cityName.Font, FontStyle.Bold);


            day.Location = new Point(10, 20);                              //label for name of day
            day.Size = new Size(35, 13);
            day.Text = Convert.ToString(wday);

            min.Location = new Point(10, 50);                             //label for minimum temperature
            min.Size = new Size(35, 13);
            if (vari.LowTemp == minT)
            {
                min.Text = Convert.ToString(minT + "°");
                min.Font = new Font(min.Font, FontStyle.Bold);
                min.ForeColor = Color.Blue;
            }
            else { min.Text = Convert.ToString(minT + "°"); }

            max.Location = new Point(10, 90);                            //label for maximum temperature
            max.Size = new Size(35, 13);
            if (vari.HighTemp == maxT)
            {
                max.Text = Convert.ToString(maxT + "°");
                max.Font = new Font(max.Font, FontStyle.Bold);
                max.ForeColor = Color.Red;
            }
            else { max.Text = Convert.ToString(maxT + "°"); }

            pre.Location = new Point(10, 130);                          //label for precipitation
            pre.Size = new Size(35, 13);
            if (vari.HighPre == precep)
            {
                pre.Text = Convert.ToString(precep + "%");
                pre.Font = new Font(pre.Font, FontStyle.Bold);
            }
            else { pre.Text = Convert.ToString(precep + "%"); }

            hum.Location = new Point(10, 170);                          //label for humidity
            hum.Size = new Size(35, 13);
            if (vari.HighHum == humid)
            {
                hum.Text = Convert.ToString(humid + "%");
                hum.Font = new Font(hum.Font, FontStyle.Bold);
            }
            else { hum.Text = Convert.ToString(humid + "%"); }

            wind.Location = new Point(10, 210);                        //label for wind speed
            wind.Size = new Size(45, 13);
            if (vari.HighWind == windSp)
            {
                wind.Text = Convert.ToString(windSp + "km/h");
                wind.Font = new Font(wind.Font, FontStyle.Bold);
            }
            else { wind.Text = Convert.ToString(windSp + "km/h"); }


            panel.Location = new Point(pnlnum, pnlcol);              //creation of panels
            panel.Size = new Size(110, 240);
            panel1.Controls.Add(panel);
            panel.Controls.Add(cityName);
            panel.Controls.Add(day);
            panel.Controls.Add(min);
            panel.Controls.Add(max);
            panel.Controls.Add(pre);
            panel.Controls.Add(hum);
            panel.Controls.Add(wind);
        }

        private void BtnAddNewFav_Click(object sender, EventArgs e)
        {
            BtnAddNewFav.Enabled = false;
            btnAddCity.Visible = true;
            cmbCity.Visible = true;
        }
    }
}

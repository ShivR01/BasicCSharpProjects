﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

//18003959 Shivaar Sanparsad
namespace WeatherForecasts
{
    public partial class Generate_Single_Multiple : Form
    {
        int dateDiff;
        int reportNum = 1;
        DateTime date;
        DateTime newdate;
        List<WeatherVariables> listarr2 = new List<WeatherVariables>();           //list of objects to store weather values
        List<WeatherVariables> highLow = new List<WeatherVariables>();            //list of objects to find highest and lowest values
        List<String> cities2 = new List<String>();                                //list of Cities
        WeatherVariables vari = new WeatherVariables();

        internal Generate_Single_Multiple(List<WeatherVariables> listarr, List<string> cities)  //Gets list of objects from previous form
        {
            InitializeComponent();
            for (int i = 0; i < listarr.Count; i++)
            {
                listarr2.Add(new WeatherVariables(listarr[i].City, listarr[i].Date, listarr[i].MinTemp, listarr[i].MaxTemp, listarr[i].Precipitation, listarr[i].Humidity, listarr[i].WindSpeed)); //Assigns objects to new list
            }
            for (int i = 0; i < cities.Count; i++)
            {
                cities2.Add(cities[i]);
            }

        }

        private void btnAddCity_Click(object sender, EventArgs e) //Adds city/cities to a list 
        {
            vari.AddCity.Add(cmbCity.SelectedItem + "");
            MessageBox.Show("City added");

            rtbCitiesAdded.Clear();
            foreach (string s in vari.AddCity)           //re displays all values in list of cities
            {
                rtbCitiesAdded.Text += s + Environment.NewLine;
            }
            btnGen.Enabled = true;
            btnMultiple.Enabled = true;
        }

        private void btnGen_Click(object sender, EventArgs e)
        {
            StreamWriter File = new StreamWriter("Report" + Convert.ToString(reportNum) + ".txt");         //Creating report for printing
            File.WriteLine("Weather Report: " + Convert.ToString(reportNum));
            File.WriteLine("----------------------");
            GetHighLow();                                //recieves the highest and lowest values
            date = Convert.ToDateTime(dtpStart.Text);
            for (int l = 0; l < vari.AddCity.Count; l++)
            {
                for (int i = 0; i < dateDiff; i++) //increments on the range of days from the difference
                {
                    newdate = date.AddDays(i);     //adds 1 day 

                    for (int j = 0; j < listarr2.Count; j++)
                    {
                        if ((listarr2[j].City == (vari.AddCity[l]) && (listarr2[j].Date == newdate)))//Checks values of selected city
                        {
                            createPanelLabel(vari.AddCity[l],vari.Panelnum[i], vari.PanelColumn[l], listarr2[j].MinTemp, listarr2[j].MaxTemp, listarr2[j].Precipitation, listarr2[j].Humidity, listarr2[j].WindSpeed, newdate.ToString("ddd"));//Dynamically creates panels displaying weather forecasts

                            File.WriteLine("City: " + vari.AddCity[l]);     //Writing to textfile 
                            File.WriteLine("Date and Day: " + newdate.ToString("ddd") + " " + listarr2[j].Date.ToShortDateString());
                            File.WriteLine("Minimum Temperature: " + listarr2[j].MinTemp + "°");
                            File.WriteLine("Maximum Temperature: " + listarr2[j].MaxTemp + "°");
                            File.WriteLine("Precipitaion: " + listarr2[j].Precipitation + "%");
                            File.WriteLine("Humidity: " + listarr2[j].Humidity + "%");
                            File.WriteLine("Wind Speed: " + listarr2[j].WindSpeed+"km/h");
                        }
                    }
                    File.WriteLine("");  //Leaves a line after each day
                }
                File.WriteLine("*****************"); //Leaves a breaker after entire City forecasts
            }
            MessageBox.Show("Report created");
            File.Close();
            Process.Start("notepad.exe", "Report" + Convert.ToString(reportNum) + ".txt");
            reportNum++;
        }

        private void GetHighLow()
        {
            date = Convert.ToDateTime(dtpStart.Text);
            dateDiff = (Convert.ToDateTime(dtpEnd.Text) - Convert.ToDateTime(dtpStart.Text)).Days; //Gets the difference in days
            for (int i = 0; i < dateDiff; i++) //increments on the range of days from the difference
            {
                newdate = date.AddDays(i);
                for (int j = 0; j < listarr2.Count; j++)
                {
                    for (int k = 0; k < vari.AddCity.Count; k++)//Checks for each city in addCity list
                    {
                        if ((listarr2[j].City == (vari.AddCity[k])) && (listarr2[j].Date == newdate))//Gets values of selected city
                        {
                            highLow.Add(new WeatherVariables(listarr2[j].MinTemp, listarr2[j].MaxTemp, listarr2[j].Precipitation, listarr2[j].Humidity, listarr2[j].WindSpeed, newdate.ToString("ddd")));
                        }
                    }
                }
            }

            for (int i = 0; i < highLow.Count; i++)//Gets highest and lowest values
            {
                if (highLow[i].MinTemp <= vari.LowTemp)//Gets lowest temp
                {
                    vari.LowTemp = highLow[i].MinTemp;
                }

                if (highLow[i].MaxTemp >= vari.HighTemp)//Gets highest temp
                {
                    vari.HighTemp = highLow[i].MaxTemp;
                }

                if (highLow[i].Precipitation >= vari.HighPre)//Gets highest Precipitation
                {
                    vari.HighPre = highLow[i].Precipitation;
                }

                if (highLow[i].Humidity >= vari.HighHum)//Gets highest Humidity
                {
                    vari.HighHum = highLow[i].Humidity;
                }

                if (highLow[i].WindSpeed >= vari.HighWind)//Gets highest Wind speed
                {
                    vari.HighWind = highLow[i].WindSpeed;
                }
            }
        }

        private void createPanelLabel(string city,int pnlnum, int pnlcol, double minT, double maxT, double precep, double humid, double windSp, string wday) //Dyanmically creates panels for generating report
        {
            Panel panel = new Panel();
            Label cityName = new Label();
            Label day = new Label();
            Label min = new Label();
            Label max = new Label();
            Label pre = new Label();
            Label hum = new Label();
            Label wind = new Label();

            cityName.Location = new Point(3, 0);                            //Label for name if city
            cityName.Size = new Size(90, 13);
            cityName.Text = city;
            cityName.Font = new Font(cityName.Font, FontStyle.Bold);


            day.Location = new Point(10, 20);                              //label for name of day
            day.Size = new Size(35, 13);
            day.Text = Convert.ToString(wday);

            min.Location = new Point(10, 50);                             //label for minimum temperature
            min.Size = new Size(35, 13);
            if (vari.LowTemp == minT)
            {
                min.Text = Convert.ToString(minT+"°");
                min.Font = new Font(min.Font, FontStyle.Bold);
                min.ForeColor = Color.Blue;
            }
            else { min.Text = Convert.ToString(minT + "°"); }

            max.Location = new Point(10, 90);                            //label for maximum temperature
            max.Size = new Size(35, 13);
            if (vari.HighTemp == maxT)
            {
                max.Text = Convert.ToString(maxT+"°");
                max.Font = new Font(max.Font, FontStyle.Bold);
                max.ForeColor = Color.Red;
            }
            else { max.Text = Convert.ToString(maxT + "°"); }

            pre.Location = new Point(10, 130);                          //label for precipitation
            pre.Size = new Size(35, 13);
            if (vari.HighPre == precep)
            {
                pre.Text = Convert.ToString(precep + "%");
                pre.Font = new Font(pre.Font, FontStyle.Bold);
            }
            else { pre.Text = Convert.ToString(precep + "%"); }

            hum.Location = new Point(10, 170);                          //label for humidity
            hum.Size = new Size(35, 13);
            if (vari.HighHum == humid)
            {
                hum.Text = Convert.ToString(humid + "%");
                hum.Font = new Font(hum.Font, FontStyle.Bold);
            }
            else { hum.Text = Convert.ToString(humid + "%"); }

            wind.Location = new Point(10, 210);                        //label for wind speed
            wind.Size = new Size(45, 13);
            if (vari.HighWind == windSp)
            {
                wind.Text = Convert.ToString(windSp + "km/h");
                wind.Font = new Font(wind.Font, FontStyle.Bold);
            }
            else { wind.Text = Convert.ToString(windSp + "km/h"); }


            panel.Location = new Point(pnlnum, pnlcol);              //creation of panels
            panel.Size = new Size(110, 240);
            panel1.Controls.Add(panel);
            panel.Controls.Add(cityName);
            panel.Controls.Add(day);
            panel.Controls.Add(min);
            panel.Controls.Add(max);
            panel.Controls.Add(pre);
            panel.Controls.Add(hum);
            panel.Controls.Add(wind);
        }

        private void btnBack_Click(object sender, EventArgs e)//returns to capture form
        {
            Capture temp = new Capture();
            temp.Show();
            this.Hide();
        }

        private void GenerateMultiple_Load(object sender, EventArgs e)
        {
            StreamWriter File = new StreamWriter("Stored.txt");         //Creating report for Storing     
            for (int i = 0; i < listarr2.Count; i++)
            {
                File.Flush();
                File.WriteLine(listarr2[i].City+"#"+Convert.ToString(listarr2[i].Date.ToShortDateString())+"#"+ Convert.ToString(listarr2[i].MinTemp) + "#"+Convert.ToString(listarr2[i].MaxTemp) + "#" //Storing entire list of objects in text file
                    + Convert.ToString(listarr2[i].MinTemp) + "#"+ Convert.ToString(listarr2[i].Precipitation) + "#"+ Convert.ToString(listarr2[i].Humidity) + "#"+ Convert.ToString(listarr2[i].WindSpeed));
            }
            WeatherVariables city = new WeatherVariables(); // loads combobox with cities
            foreach (var item in cities2)
            {
                cmbCity.Items.Add(item);
            }
            lblAdded.Visible = false;
            rtbCitiesAdded.Visible = false;
            btnGen.Enabled = false;
            btnMultiple.Enabled = false;
        }

        private void btnExit_Click(object sender, EventArgs e)//Exits all forms
        {
                if (MessageBox.Show("Are you sure want to exit?", "Weather App", MessageBoxButtons.OKCancel, MessageBoxIcon.Information) == DialogResult.OK)
                {
                    Application.Exit();
                }
        }


        private void btnMultiple_Click(object sender, EventArgs e)//changes from single to multiple gen form look
        {
            panel1.Controls.Clear();
            btnAddCity.Text = "ADD ANOTHER CITY";
            label1.Text = "Report for multiple cities:";
            lblAdded.Visible = true;
            rtbCitiesAdded.Visible = true;
            rtbCitiesAdded.Text = vari.AddCity[0];
            btnGen.Enabled = false;
        }
    }
}

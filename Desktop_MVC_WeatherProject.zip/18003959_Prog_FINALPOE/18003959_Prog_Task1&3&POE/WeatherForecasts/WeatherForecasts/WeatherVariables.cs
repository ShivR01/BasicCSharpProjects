﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

//18003959 Shivaar Sanparsad
namespace WeatherForecasts
{
   internal class WeatherVariables //Internal keyword used from https://stackoverflow.com/questions/165719/practical-uses-for-the-internal-keyword-in-c-sharp
    {
        private string city;
        private DateTime date;
        private double minTemp;
        private double maxTemp;
        private double precipitation;
        private double humidity;
        private double windSpeed;
        private string day;
        private double lowTemp = 100;//variable for getting lowest temp
        private double highTemp = 0;//variable for getting highest temp
        private double highPre = 0;//variable for getting highest precipitation
        private double highHum = 0;//variable for getting highest humidity
        private double highWind = 0;//variable for getting highest wind speed
        private string username;
        private string password;
        int[] panelnum = new int[] { 3, 120, 235, 350, 465, 580, 695 }; //used to get location of dynamic panels
        int[] panelColumn = new int[] { 3, 250, 495, 740 };  //used to get location of dynamic panels
        List<String> addCity = new List<String>();
        private Boolean valid = false;

        public WeatherVariables()//For variables
        {
        }

        public WeatherVariables(string city, DateTime date, double minTemp, double maxTemp, double precipitation, double humidity, double windSpeed)//For capture
        {
            this.city = city;
            this.date = date;
            this.minTemp = minTemp;
            this.maxTemp = maxTemp;
            this.precipitation = precipitation;
            this.humidity = humidity;
            this.windSpeed = windSpeed;
        }

        public WeatherVariables(string city, DateTime date)//For capture
        {
            this.city = city;
            this.date = date;
        }

        public WeatherVariables(double minTemp, double maxTemp, double precipitation, double humidity, double windSpeed, string day)//For report
        {
            this.minTemp = minTemp;
            this.maxTemp = maxTemp;
            this.precipitation = precipitation;
            this.humidity = humidity;
            this.windSpeed = windSpeed;
            this.day = day;
        }

        public WeatherVariables(string username, string password)// For login
        {
            this.username = username;
            this.password = password;
        }

        public string City { get => city; set => city = value; }
        public DateTime Date { get => date; set => date = value; }
        public double MinTemp { get => minTemp; set => minTemp = value; }
        public double MaxTemp { get => maxTemp; set => maxTemp = value; }
        public double Precipitation { get => precipitation; set => precipitation = value; }
        public double Humidity { get => humidity; set => humidity = value; }
        public double WindSpeed { get => windSpeed; set => windSpeed = value; }
        public int[] Panelnum { get => panelnum; set => panelnum = value; }
        public string Day { get => day; set => day = value; }
        public double LowTemp { get => lowTemp; set => lowTemp = value; }
        public double HighTemp { get => highTemp; set => highTemp = value; }
        public double HighPre { get => highPre; set => highPre = value; }
        public double HighHum { get => highHum; set => highHum = value; }
        public double HighWind { get => highWind; set => highWind = value; }
        public int[] PanelColumn { get => panelColumn; set => panelColumn = value; }
        public List<string> AddCity { get => addCity; set => addCity = value; }
        public string Username { get => username; set => username = value; }
        public string Password { get => password; set => password = value; }
        public bool Valid { get => valid; set => valid = value; }

        public int RandomNumber(int min, int max) //Generate random numbers for auto fill in capture form
        {
            Random random = new Random();
            return random.Next(min, max);
        }

        public Boolean reject(string value)//code used from classmate Theolin 
        {
            String pattern = @"^(?:100|[1-9]?[0-9])$";
            if (Regex.IsMatch(value,pattern))
            {
                return valid = true;
            }
            return valid = false;
        }

    }
}

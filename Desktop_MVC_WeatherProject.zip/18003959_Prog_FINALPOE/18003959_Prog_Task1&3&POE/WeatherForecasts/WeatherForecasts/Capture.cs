﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

//18003959 Shivaar Sanparsad
namespace WeatherForecasts
{
    public partial class Capture : Form
    {
        List<WeatherVariables> listarr = new List<WeatherVariables>(); //Declaring list of objects globally
        List<String> cities = new List<String>() { "Durban", "Cape Town", "Johannesburg", "Pretoria" };
        WeatherVariables vari = new WeatherVariables();
        public Capture()
        {
            InitializeComponent();
        }

        private void btnAdd_Click(object sender, EventArgs e)//Add forecasts
        {
            if (vari.reject(tbMin.Text) == true && vari.reject(tbMax.Text) == true && vari.reject(tbPre.Text) == true && vari.reject(tbHum.Text) == true && vari.reject(tbSpeed.Text) == true)//checks if valid characters are typed in
            {
                int flag = 999;

                listarr.Add(new WeatherVariables(tbCity.Text, Convert.ToDateTime(dtpDate.Text),           //List of objects capture
                    Convert.ToDouble(tbMin.Text), Convert.ToDouble(tbMax.Text), Convert.ToDouble(tbPre.Text),
                    Convert.ToDouble(tbHum.Text), Convert.ToDouble(tbSpeed.Text)));
                for (int i = 0; i < cities.Count; i++) //Adds new city inputted
                {
                    if (tbCity.Text != cities[i])
                    {
                        flag = 0;
                    }
                    else
                    {
                        flag = 1;
                        break;
                    }
                }
                if (flag == 0)
                {
                    cities.Add(tbCity.Text); //adds new city
                try
                { 
                    using (SqlConnection con = new SqlConnection(Properties.Settings.Default.ConString))//Adds new city to database
                    {
                        string sqlQuery = "Insert into Cities (City) VALUES (@City); ";
                        con.Open();
                        using (SqlCommand cmd = new SqlCommand(sqlQuery, con))
                        {
                            cmd.Parameters.AddWithValue("@City", tbCity.Text);
                            cmd.ExecuteNonQuery();

                            if (con.State == ConnectionState.Open)
                                con.Close();
                            MessageBox.Show("New city added successfully");
                        }
                    }
                }
                catch (Exception)
                {
                    throw;
                }
            }
                //Database capture
                WeatherVariables capture = new WeatherVariables(tbCity.Text,
                    Convert.ToDateTime(dtpDate.Text), Convert.ToDouble(tbMin.Text), Convert.ToDouble(tbMax.Text),
                    Convert.ToDouble(tbPre.Text), Convert.ToDouble(tbHum.Text), Convert.ToDouble(tbSpeed.Text));
                Random rnd = new Random();
                double id = rnd.Next(6, 999);
                
                try
                {
                    using (SqlConnection con = new SqlConnection(Properties.Settings.Default.ConString))//Code used to store all databse forecasts in array of objects
                    {
                        string sqlQuery = "Insert into Forecasts (FID, City, WeatherDate, MinTemp, MaxTemp, Prec, Humid, Wind) VALUES (@FID,@City,@WeatherDate,@MinTemp,@MaxTemp,@Prec,@Humid,@Wind); ";
                        con.Open();
                        using (SqlCommand cmd = new SqlCommand(sqlQuery, con))
                        {
                            cmd.Parameters.AddWithValue("@FID", id);
                            cmd.Parameters.AddWithValue("@City", capture.City);
                            cmd.Parameters.AddWithValue("@WeatherDate", capture.Date);
                            cmd.Parameters.AddWithValue("@MinTemp", capture.MinTemp);
                            cmd.Parameters.AddWithValue("@MaxTemp", capture.MaxTemp);
                            cmd.Parameters.AddWithValue("@Prec", capture.Precipitation);
                            cmd.Parameters.AddWithValue("@Humid", capture.Humidity);
                            cmd.Parameters.AddWithValue("@Wind", capture.WindSpeed);
                            cmd.ExecuteNonQuery();


                            if (con.State == ConnectionState.Open)
                                con.Close();
                            MessageBox.Show("Forecast added successfully");
                        }
                    }
                }
                catch (Exception)
                {
                    throw;
                }
            }
            else {
                MessageBox.Show("Invalid character typed");
            }
        }

        private void btnFill_Click(object sender, EventArgs e)//Random data fill button
        {
            DateTime theDate = DateTime.Today;
            tbCity.Text = cities[vari.RandomNumber(0, cities.Count)]; 
            dtpDate.Value = DateTime.Today.AddDays(vari.RandomNumber(7,14)); //only after 7 days
            tbMin.Text = Convert.ToString(vari.RandomNumber(0, 25));
            tbMax.Text = Convert.ToString(vari.RandomNumber(15, 35));
            tbPre.Text = Convert.ToString(vari.RandomNumber(0, 100));
            tbHum.Text = Convert.ToString(vari.RandomNumber(0, 100));
            tbSpeed.Text = Convert.ToString(vari.RandomNumber(10, 20));
        }

        private void Capture_Load(object sender, EventArgs e) //Adds dummy data
        {
            vari.Date = Convert.ToDateTime(dtpDate.Text);
            listarr.Add(new WeatherVariables("Durban", vari.Date, 20, 27, 60, 74, 18));
            listarr.Add(new WeatherVariables("Cape Town", vari.Date, 24, 29, 40, 62, 12));
            listarr.Add(new WeatherVariables("Johannesburg", vari.Date, 18, 24, 35, 40, 10));
            listarr.Add(new WeatherVariables("Pretoria", vari.Date, 15, 26, 24, 57, 11));

            vari.Date = DateTime.Today.AddDays(1);
            listarr.Add(new WeatherVariables("Durban", vari.Date, 22, 25, 78, 54, 11));
            listarr.Add(new WeatherVariables("Cape Town", vari.Date, 15, 22, 55, 78, 16));
            listarr.Add(new WeatherVariables("Johannesburg", vari.Date, 14, 20, 89, 23, 19));
            listarr.Add(new WeatherVariables("Pretoria", vari.Date, 18, 25, 58, 68, 16));

            vari.Date = DateTime.Today.AddDays(2);
            listarr.Add(new WeatherVariables("Durban", vari.Date, 25, 28, 64, 55, 19));
            listarr.Add(new WeatherVariables("Cape Town", vari.Date, 18, 24, 60, 70, 10));
            listarr.Add(new WeatherVariables("Johannesburg", vari.Date, 17, 24, 74, 59, 15));
            listarr.Add(new WeatherVariables("Pretoria", vari.Date, 19, 25, 78, 68, 12));

            vari.Date = DateTime.Today.AddDays(3);
            listarr.Add(new WeatherVariables("Durban", vari.Date, 24, 29, 79, 23, 12));
            listarr.Add(new WeatherVariables("Cape Town", vari.Date, 20, 25, 68, 34, 16));
            listarr.Add(new WeatherVariables("Johannesburg", vari.Date, 10, 19, 80, 30, 20));
            listarr.Add(new WeatherVariables("Pretoria", vari.Date, 20, 22, 40, 30, 15));

            vari.Date = DateTime.Today.AddDays(4);
            listarr.Add(new WeatherVariables("Durban", vari.Date, 12, 17, 99, 23, 20));
            listarr.Add(new WeatherVariables("Cape Town", vari.Date, 22, 32, 10, 50, 11));
            listarr.Add(new WeatherVariables("Johannesburg", vari.Date, 10, 15, 90, 10, 16));
            listarr.Add(new WeatherVariables("Pretoria", vari.Date, 17, 23, 24, 80, 10));

            vari.Date = DateTime.Today.AddDays(5);
            listarr.Add(new WeatherVariables("Durban", vari.Date, 12, 15, 66, 20, 15));
            listarr.Add(new WeatherVariables("Cape Town", vari.Date, 24, 30, 12, 88, 13));
            listarr.Add(new WeatherVariables("Johannesburg", vari.Date, 15, 22, 98, 25, 20));
            listarr.Add(new WeatherVariables("Pretoria", vari.Date, 24, 26, 55, 77, 13));

            vari.Date = DateTime.Today.AddDays(6);
            listarr.Add(new WeatherVariables("Durban", vari.Date, 13, 20, 89, 12, 15));
            listarr.Add(new WeatherVariables("Cape Town", vari.Date, 26, 29, 12, 90, 10));
            listarr.Add(new WeatherVariables("Johannesburg", vari.Date, 8, 15, 80, 12, 18));
            listarr.Add(new WeatherVariables("Pretoria", vari.Date, 12, 22, 69, 21, 14));

            try
            {
                using (SqlConnection con = new SqlConnection(Properties.Settings.Default.ConString))//Gets database dummy values
                {
                    string sqlQuery = "Select * from Forecasts";
                    con.Open();
                    using (SqlCommand cmd = new SqlCommand(sqlQuery, con))
                    {
                        SqlDataReader dataReader = cmd.ExecuteReader();
                        while (dataReader.Read())
                        {
                            listarr.Add(new WeatherVariables(dataReader.GetString(1), dataReader.GetDateTime(2), Convert.ToDouble(dataReader.GetDecimal(3)), Convert.ToDouble(dataReader.GetDecimal(4)), Convert.ToDouble(dataReader.GetDecimal(5)), Convert.ToDouble(dataReader.GetDecimal(6)), Convert.ToDouble(dataReader.GetDecimal(7))));
                        }

                        dataReader.Close();
                        if (con.State == ConnectionState.Open)
                            con.Close();
                        cmd.Dispose();
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        private void btnGen_Click(object sender, EventArgs e)//Button to go to report form
        {
            Generate_Single_Multiple passing = new Generate_Single_Multiple(listarr, cities);
            passing.Show();
            this.Hide();
        }

        private void btnExit_Click(object sender, EventArgs e)//Exits all forms
        {
            {
                if (MessageBox.Show("Are you sure want to exit?","Weather App", MessageBoxButtons.OKCancel, MessageBoxIcon.Information) == DialogResult.OK)
                {
                    Application.Exit();
                }
            }
        }

        private void btnedview_Click(object sender, EventArgs e)// Goes to edit form
        {
            Edit passing = new Edit(listarr);
            passing.Show();
            this.Hide();
        }
    }
}


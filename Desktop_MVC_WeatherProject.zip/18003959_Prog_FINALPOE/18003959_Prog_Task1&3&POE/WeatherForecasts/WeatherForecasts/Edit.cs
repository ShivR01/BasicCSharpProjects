﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WeatherForecasts
{
    public partial class Edit : Form
    {
        List<String> cities = new List<String>() { "Durban", "Cape Town", "Johannesburg", "Pretoria" };
        List<WeatherVariables> listarr2 = new List<WeatherVariables>(); //Declaring list of objects globally
        List<WeatherVariables> display = new List<WeatherVariables>();
        ArrayList test = new ArrayList();
        WeatherVariables vari = new WeatherVariables();
        string idCity;                             //id variables to be used when updating changes to the data
        DateTime idDate;
        internal Edit(List<WeatherVariables> listarr) //Gets list of objects from previous form
        {
            InitializeComponent();
            for (int i = 0; i < listarr.Count; i++)//adds previous data in list of objects from capture form to current list
            {
                listarr2.Add(new WeatherVariables(listarr[i].City, listarr[i].Date, listarr[i].MinTemp, listarr[i].MaxTemp, listarr[i].Precipitation, listarr[i].Humidity, listarr[i].WindSpeed)); //Assigns objects to new list
            }
        }

        private void Edit_Load(object sender, EventArgs e) //Loads list box with list of objects data
        {
            //Code using database
            btnEdit.Enabled = false;
            btnSave.Enabled = false;

            try
            {
                using (SqlConnection con = new SqlConnection(Properties.Settings.Default.ConString))
                {
                    string sqlQuery = "Select * from Forecasts";
                    con.Open();
                    using (SqlCommand cmd = new SqlCommand(sqlQuery, con))
                    {
                        SqlDataReader dataReader = cmd.ExecuteReader();
                        while (dataReader.Read())
                        {
                            WeatherVariables temp = new WeatherVariables(dataReader.GetString(1), dataReader.GetDateTime(2));
                            test.Add(temp);
                        }

                        dataReader.Close();
                        if (con.State == ConnectionState.Open)
                        con.Close();
                        cmd.Dispose();
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }
            lbSelect.Items.Clear();
            foreach (WeatherVariables testy in test)
            {
                lbSelect.Items.Add(testy.City + " " + Convert.ToString(testy.Date));
            }
            //lbSelect.Items.Clear();
            //for (int i = 0; i < listarr2.Count; i++)
            //{
            //    lbSelect.Items.Add(listarr2[i].City + " " + Convert.ToString(listarr2[i].Date));
            //}   
        }

        private void btnExit_Click(object sender, EventArgs e) //Exits entire program
        {
           if (MessageBox.Show("Are you sure want to exit?", "Weather App", MessageBoxButtons.OKCancel, MessageBoxIcon.Information) == DialogResult.OK)
           {
                    Application.Exit();
           }
            
        }

        private void lbSelect_SelectedIndexChanged(object sender, EventArgs e) //Code for displaying sample
        {
            tbDisplay.Clear();
            btnEdit.Enabled = true;

            string weatherSelected = lbSelect.SelectedItem.ToString();

            for (int i = 0; i < listarr2.Count; i++)  //Checks if item selected from list box matches array of objects
            {
                if ((listarr2[i].City + " " + listarr2[i].Date).Equals(weatherSelected))// if it does match then adds data to temp list for displaying
                {
                    display.Add(new WeatherVariables(listarr2[i].City, listarr2[i].Date, listarr2[i].MinTemp, listarr2[i].MaxTemp, listarr2[i].Precipitation, listarr2[i].Humidity, listarr2[i].WindSpeed));
                    break;
                }
            }
            List<string> weatherInfo = new List<string>();           //New list for format use
            weatherInfo.Add("Forecast");
            weatherInfo.Add("-------------------------");
            weatherInfo.Add("City: " + display[0].City);
            weatherInfo.Add("Date: " + (Convert.ToString(display[0].Date)));
            weatherInfo.Add("MinTemp: " + (Convert.ToString(display[0].MinTemp)));
            weatherInfo.Add("MaxTemp: " + (Convert.ToString(display[0].MaxTemp)));
            weatherInfo.Add("Precipitation: " + (Convert.ToString(display[0].Precipitation)));
            weatherInfo.Add("Humidity: " + (Convert.ToString(display[0].Humidity)));
            weatherInfo.Add("Wind Speed: " + (Convert.ToString(display[0].WindSpeed)));

            tbDisplay.Lines = weatherInfo.ToArray<string>();
            display.Clear();
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            btnEdit.Enabled = false;
            btnSave.Enabled = true;
            tbDisplay.Clear();

            string weatherSelected = lbSelect.SelectedItem.ToString();

            for (int i = 0; i < listarr2.Count; i++)  //Checks if item selected from list box matches array of objects
            {
                if ((listarr2[i].City + " " + listarr2[i].Date).Equals(weatherSelected))// if it does match then adds data to text boxes for editing
                {
                    tbCity.Text = listarr2[i].City;
                    dtpDate.Text = Convert.ToString(listarr2[i].Date);
                    tbMin.Text = Convert.ToString(listarr2[i].MinTemp);
                    tbMax.Text = Convert.ToString(listarr2[i].MaxTemp);
                    tbPre.Text = Convert.ToString(listarr2[i].Precipitation);
                    tbHum.Text = Convert.ToString(listarr2[i].Humidity);
                    tbSpeed.Text = Convert.ToString(listarr2[i].WindSpeed);
                    break;
                }
            }
            btnEdit.Enabled = false;
             idCity = tbCity.Text;                                //id variables to be used when updating changes to the data
             idDate = Convert.ToDateTime(dtpDate.Text);

        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (vari.reject(tbMin.Text) == true && vari.reject(tbMax.Text) == true && vari.reject(tbPre.Text) == true && vari.reject(tbHum.Text) == true && vari.reject(tbSpeed.Text) == true)//checks if valid characters are typed in
            {
                WeatherVariables capture = new WeatherVariables(tbCity.Text,
                    Convert.ToDateTime(dtpDate.Text), Convert.ToDouble(tbMin.Text), Convert.ToDouble(tbMax.Text),
                    Convert.ToDouble(tbPre.Text), Convert.ToDouble(tbHum.Text), Convert.ToDouble(tbSpeed.Text));
                try
                {
                    SqlConnection con = new SqlConnection(Properties.Settings.Default.ConString);
                        con.Open();
                    string sqlQuery = "Update Forecasts set City=@City, " + "WeatherDate=@WeatherDate," + "MinTemp=@MinTemp," + "MaxTemp=@MaxTemp," + "Prec=@Prec," + "Humid=@Humid," + "Wind=@Wind" + " WHERE City=@CityID AND WeatherDate=@DateID";
                    using (SqlCommand cmd = new SqlCommand(sqlQuery, con))
                    {
                        cmd.Parameters.AddWithValue("@City", capture.City);
                        cmd.Parameters.AddWithValue("@WeatherDate", capture.Date);
                        cmd.Parameters.AddWithValue("@MinTemp", capture.MinTemp);
                        cmd.Parameters.AddWithValue("@MaxTemp", capture.MaxTemp);
                        cmd.Parameters.AddWithValue("@Prec", capture.Precipitation);
                        cmd.Parameters.AddWithValue("@Humid", capture.Humidity);
                        cmd.Parameters.AddWithValue("@Wind", capture.WindSpeed);
                        cmd.Parameters.AddWithValue("@CityID", idCity);
                        cmd.Parameters.AddWithValue("@DateID", idDate);
                        cmd.ExecuteNonQuery();

                        if (con.State == ConnectionState.Open)
                            con.Close();
                        MessageBox.Show("Forecast updated successfully");
                    }


                }
                catch (Exception)
                {
                    throw;
                }

                for (int i = 0; i < listarr2.Count; i++)  //Checks if item selected from list box matches array of objects
                {
                    if ((listarr2[i].City == idCity) && (listarr2[i].Date == idDate))//Updates forecast in array
                    {
                        listarr2[i].City = tbCity.Text;
                        listarr2[i].Date = Convert.ToDateTime(dtpDate.Text);
                        listarr2[i].MinTemp = Convert.ToDouble(tbMin.Text);
                        listarr2[i].MaxTemp = Convert.ToDouble(tbMax.Text);
                        listarr2[i].Precipitation = Convert.ToDouble(tbPre.Text);
                        listarr2[i].Humidity = Convert.ToDouble(tbHum.Text);
                        listarr2[i].WindSpeed = Convert.ToDouble(tbSpeed.Text);
                        break;
                    }
                }


                lbSelect.Items.Clear();
                foreach (WeatherVariables testy in test)// Enters updated values in listbox
                {
                    lbSelect.Items.Add(testy.City + " " + Convert.ToString(testy.Date));
                }

            }
            else
            {
                MessageBox.Show("Invalid character typed");
            }

            tbCity.Clear();
            tbMax.Clear();
            tbMin.Clear();
            tbPre.Clear();
            tbHum.Clear();
            tbSpeed.Clear();
            btnSave.Enabled = false;
            btnEdit.Enabled = false;
        }

        private void btnClear_Click(object sender, EventArgs e)//Clears all text
        {
            tbCity.Clear();
            tbMax.Clear();
            tbMin.Clear();
            tbPre.Clear();
            tbHum.Clear();
            tbSpeed.Clear();
            btnSave.Enabled = false;
            btnEdit.Enabled = false;
        }

        private void btnBack_Click(object sender, EventArgs e) //Passes array list to generate form for generating and storing in text file
        {
            Generate_Single_Multiple passing = new Generate_Single_Multiple(listarr2,cities);
            passing.Show();
            this.Hide();
        }
    }
}


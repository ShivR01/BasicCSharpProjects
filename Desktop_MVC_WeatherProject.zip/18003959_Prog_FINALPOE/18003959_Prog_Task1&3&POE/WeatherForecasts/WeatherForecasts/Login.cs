﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

//18003959 Shivaar Sanparsad
namespace WeatherForecasts
{
    public partial class Login : Form
    {
        List<String> Username = new List<String>();
        List<String> Password = new List<String>();
        public Login()
        {
            Thread t = new Thread(new ThreadStart(splashStart));   //Code for splash screen taken from youtube video https://www.youtube.com/watch?v=J9azEeLwymU
            t.Start();
            Thread.Sleep(5000);
            InitializeComponent();
            t.Abort();
        }

        public void splashStart()//Code for splash screen taken from youtube video https://www.youtube.com/watch?v=J9azEeLwymU
        {
            Application.Run(new Splash());
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string user;
            int flag = 0;
            //Code for databse login
            try
            {
                using (SqlConnection con = new SqlConnection(Properties.Settings.Default.ConString))//Gets the all the values for username and pass in the databse
                {
                    string sqlQuery = "select* from Users";
                    con.Open();
                    using (SqlCommand cmd = new SqlCommand(sqlQuery, con))
                    {
                        SqlDataReader dataReader = cmd.ExecuteReader();
                        while (dataReader.Read())
                        {
                            Username.Add(dataReader.GetString(0));
                            Password.Add(dataReader.GetString(1));
                        }

                        dataReader.Close();
                        if (con.State == ConnectionState.Open)
                            con.Close();
                        cmd.Dispose();
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }
            for (int i = 0; i < Username.Count; i++)
            {
                if ((Username[i] == tbUser.Text) && (Password[i] == tbPass.Text))
                {
                    if ((tbUser.Text == "ShivWeather") || (tbUser.Text == "ProgEbWeather") || (tbUser.Text == "SanWeather")) //if usernames eaquals any of the following then show capture form
                    {
                        Capture temp = new Capture();
                        temp.Show();
                        this.Hide();
                        flag = 0;
                    }
                    else
                    {
                        user = tbUser.Text;
                        GeneralUser temp = new GeneralUser(user); //else show general users form
                        temp.Show();
                        this.Hide();
                        flag = 0;
                    }
                    break;
                }
                else
                {
                    flag += 1;
                }
            }
            if (flag > 0)
            {
                MessageBox.Show("Please enter a valid Username and Password.");
            }
        }

        private void btnExit_Click(object sender, EventArgs e)//Exits program, Code taken from https://stackoverflow.com/questions/24693942/c-sharp-close-all-forms
        {
            {
                if (MessageBox.Show("Are you sure want to exit?", "Weather App", MessageBoxButtons.OKCancel, MessageBoxIcon.Information) == DialogResult.OK)
                {
                    Application.Exit();
                }
            }
        }

        private void btnFill_Click(object sender, EventArgs e)//Fills textboxes with username and password from text file Login.txt
        {
            tbUser.Text = "ProgEbWeather";
            tbPass.Text = "Forecaster2";
            //TextFile format:
            //ShivWeather#Forecaster1
            //ProgEbWeather#Forecaster2 
            //SanWeather#Forecaster3
            //GenUser1#Gen1
            //GenUser2#Gen2
        }

        private void btngenU_Click(object sender, EventArgs e)//Fills textboxes with username and password from text file Login.txt
        {
            tbUser.Text = "GenUser1";
            tbPass.Text = "Gen1";
            //TextFile format:
            //ShivWeather#Forecaster1
            //ProgEbWeather#Forecaster2 
            //SanWeather#Forecaster3
            //GenUser1#Gen1
            //GenUser2#Gen2
        }

 
    }
}


//    //CODE USING TEXTFILE BELOW
//    string user;
//    List<WeatherVariables> userpass = new List<WeatherVariables>(); //List of usernames and passwords      
//    using (var f = new StreamReader("Login.txt"))
//    {
//        string line;
//        while ((line = f.ReadLine()) != null)
//        {
//            var parts = line.Split('#'); //splits lines seperated by delimiter
//            userpass.Add(new WeatherVariables(parts[0], parts[1]));
//        }
//    }

//    int flag = 0;
//    for (int i = 0; i < userpass.Count; i++)
//    {
//        if ((tbUser.Text == userpass[i].Username) && (tbPass.Text == userpass[i].Password))//checks if username and password match the ones recieved from text file
//        {
//            if ((tbUser.Text == "ShivWeather") || (tbUser.Text == "ProgEbWeather") || (tbUser.Text == "SanWeather")) //if usernames eaquals any of the following then show capture form
//            {
//                Capture temp = new Capture();
//                temp.Show();
//                this.Hide();
//                flag = 0;
//            }
//            else {
//                user = tbUser.Text;
//                GeneralUser temp = new GeneralUser(user); //else show general users form
//                temp.Show();
//                this.Hide();
//                flag = 0;
//            }
//            break;
//        }
//        else
//        {
//            flag += 1;
//        }
//    }

//    if (flag > 0)
//    {
//        MessageBox.Show("Please enter a valid Username and Password.");
//    }
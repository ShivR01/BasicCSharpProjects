﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _18003959_TaskManager
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            ListAllProcess();
        }

        public void ListAllProcess()//Lists all processes currently running
        {
            Process[] AllProcess = Process.GetProcesses();
            foreach (Process p1 in AllProcess)
            {
                try
                {
                    dataGridView1.Rows.Add(p1.ProcessName, p1.Id, p1.StartTime.ToShortDateString());
                }
                catch (Exception ex)
                {

                }
            }
        }

        private void btnModules_Click(object sender, EventArgs e)
        {
            Process mod = Process.GetProcessById(Convert.ToInt32(dataGridView1.CurrentRow.Cells[1].Value.ToString()));
            String s = "";
            foreach (ProcessModule module in mod.Modules)
            {
                s += module.FileName + " " + module.ModuleName + "\n";

            }
            MessageBox.Show(s);
        }

        private void btnThreads_Click(object sender, EventArgs e)
        {
            Process threads = Process.GetProcessById(Convert.ToInt32(dataGridView1.CurrentRow.Cells[1].Value.ToString()));
            String s = "";
            foreach (ProcessThread thread in threads.Threads)
            {
                s += thread.Id + " " + thread.PriorityLevel + "\n";

            }
            MessageBox.Show(s);
        }

        private void btnAss_Click(object sender, EventArgs e)
        {
            String a = "";
            foreach (System.Reflection.Assembly item in AppDomain.CurrentDomain.GetAssemblies())
            {
                a += item.FullName + "\n";

            }

            MessageBox.Show(a);
        }

        private void btnStartChrome_Click(object sender, EventArgs e)
        {
            Process.Start("chrome.exe", "http://www.varsitycollege.co.za/my-vc");
        }

        private void btnKill_Click(object sender, EventArgs e)
        {
            Process.GetProcesses()
                .Where(x => x.ProcessName.ToLower()
                .StartsWith("chrome"))

                .ToList()
                .ForEach(x => x.Kill());


            MessageBox.Show("Kill Success");
        }

        private void btnTaskEnd_Click(object sender, EventArgs e)
        {
            Process.GetProcesses()
              .Where(x => x.ProcessName.ToLower()
              .StartsWith("18003959_taskmanager"))

              .ToList()
              .ForEach(x => x.Kill());
        }
    }
}

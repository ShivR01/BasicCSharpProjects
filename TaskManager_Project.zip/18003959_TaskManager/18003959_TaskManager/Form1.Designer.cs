﻿namespace _18003959_TaskManager
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnTaskEnd = new System.Windows.Forms.Button();
            this.btnStartChrome = new System.Windows.Forms.Button();
            this.btnAss = new System.Windows.Forms.Button();
            this.btnModules = new System.Windows.Forms.Button();
            this.btnThreads = new System.Windows.Forms.Button();
            this.btnKill = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2,
            this.Column3});
            this.dataGridView1.Location = new System.Drawing.Point(12, 12);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(345, 426);
            this.dataGridView1.TabIndex = 0;
            // 
            // Column1
            // 
            this.Column1.HeaderText = "Process Name";
            this.Column1.Name = "Column1";
            // 
            // Column2
            // 
            this.Column2.HeaderText = "PID";
            this.Column2.Name = "Column2";
            // 
            // Column3
            // 
            this.Column3.HeaderText = "Date";
            this.Column3.Name = "Column3";
            // 
            // btnTaskEnd
            // 
            this.btnTaskEnd.Location = new System.Drawing.Point(601, 238);
            this.btnTaskEnd.Name = "btnTaskEnd";
            this.btnTaskEnd.Size = new System.Drawing.Size(104, 63);
            this.btnTaskEnd.TabIndex = 13;
            this.btnTaskEnd.Text = "End Task Manager";
            this.btnTaskEnd.UseVisualStyleBackColor = true;
            this.btnTaskEnd.Click += new System.EventHandler(this.btnTaskEnd_Click);
            // 
            // btnStartChrome
            // 
            this.btnStartChrome.Location = new System.Drawing.Point(381, 238);
            this.btnStartChrome.Name = "btnStartChrome";
            this.btnStartChrome.Size = new System.Drawing.Size(104, 63);
            this.btnStartChrome.TabIndex = 12;
            this.btnStartChrome.Text = "Open VC website";
            this.btnStartChrome.UseVisualStyleBackColor = true;
            this.btnStartChrome.Click += new System.EventHandler(this.btnStartChrome_Click);
            // 
            // btnAss
            // 
            this.btnAss.Location = new System.Drawing.Point(381, 169);
            this.btnAss.Name = "btnAss";
            this.btnAss.Size = new System.Drawing.Size(104, 63);
            this.btnAss.TabIndex = 11;
            this.btnAss.Text = "Assemblies in App Domain";
            this.btnAss.UseVisualStyleBackColor = true;
            this.btnAss.Click += new System.EventHandler(this.btnAss_Click);
            // 
            // btnModules
            // 
            this.btnModules.Location = new System.Drawing.Point(381, 100);
            this.btnModules.Name = "btnModules";
            this.btnModules.Size = new System.Drawing.Size(104, 63);
            this.btnModules.TabIndex = 10;
            this.btnModules.Text = "Loaded Modules of Selected Process";
            this.btnModules.UseVisualStyleBackColor = true;
            this.btnModules.Click += new System.EventHandler(this.btnModules_Click);
            // 
            // btnThreads
            // 
            this.btnThreads.Location = new System.Drawing.Point(491, 100);
            this.btnThreads.Name = "btnThreads";
            this.btnThreads.Size = new System.Drawing.Size(104, 63);
            this.btnThreads.TabIndex = 9;
            this.btnThreads.Text = "Threads of Selected Process";
            this.btnThreads.UseVisualStyleBackColor = true;
            this.btnThreads.Click += new System.EventHandler(this.btnThreads_Click);
            // 
            // btnKill
            // 
            this.btnKill.Location = new System.Drawing.Point(491, 238);
            this.btnKill.Name = "btnKill";
            this.btnKill.Size = new System.Drawing.Size(104, 63);
            this.btnKill.TabIndex = 8;
            this.btnKill.Text = "Kill Chrome";
            this.btnKill.UseVisualStyleBackColor = true;
            this.btnKill.Click += new System.EventHandler(this.btnKill_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnTaskEnd);
            this.Controls.Add(this.btnStartChrome);
            this.Controls.Add(this.btnAss);
            this.Controls.Add(this.btnModules);
            this.Controls.Add(this.btnThreads);
            this.Controls.Add(this.btnKill);
            this.Controls.Add(this.dataGridView1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.Button btnTaskEnd;
        private System.Windows.Forms.Button btnStartChrome;
        private System.Windows.Forms.Button btnAss;
        private System.Windows.Forms.Button btnModules;
        private System.Windows.Forms.Button btnThreads;
        private System.Windows.Forms.Button btnKill;
    }
}


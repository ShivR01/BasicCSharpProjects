﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ContactsApp
{
    public partial class ContactsForm : Form
    {
        ArrayList contacts = new ArrayList();
        public ContactsForm()
        {
            InitializeComponent();
        }

        private void ContactsForm_Load(object sender, EventArgs e)
        {
            contacts.Clear();
            string line;

            try
            {
                StreamReader file = new StreamReader("Contacts.txt");
                while ((line = file.ReadLine()) != null)
                {
                    var lineParts = line.Split(',');
                    Contact temp = new Contact(lineParts[0], lineParts[1], lineParts[2], lineParts[3]);
                    contacts.Add(temp);
                }
                file.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }

            listBox1.Items.Clear();
            foreach (Contact contact in contacts)
            {
                listBox1.Items.Add(contact.Name + " " + contact.Surname);
            }

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selectedName = listBox1.SelectedItem.ToString();

            Contact selectedContact = new Contact();

            foreach (Contact contact in contacts)
            {
                if ((contact.Name + " " + contact.Surname).Equals(selectedName))
                {
                    selectedContact = contact;
                    break;
                }
            }

            List<string> contactInfo = new List<string>();
            contactInfo.Add("Details");
            contactInfo.Add("-------------------------");
            contactInfo.Add("Name: " + selectedContact.Name);
            contactInfo.Add("Surname: " + selectedContact.Surname);
            contactInfo.Add("Cell: " + selectedContact.Cellphone);
            contactInfo.Add("Email: " + selectedContact.Email);
            
            textBox5.Lines = contactInfo.ToArray<string>();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Contact newContact = new Contact(textBox1.Text, textBox2.Text, textBox3.Text, textBox4.Text);
            contacts.Add(newContact);

            try
            {
                StreamWriter sw = new StreamWriter("Contacts.txt");
                foreach (Contact c in contacts)
                {
                    sw.WriteLine(c.Name + "," + c.Surname + "," + c.Cellphone + "," + c.Email);
                }
                sw.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }

            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();

            listBox1.Items.Clear();
            foreach (Contact contact in contacts)
            {
                listBox1.Items.Add(contact.Name + " " + contact.Surname);
            }
        }
    }
}

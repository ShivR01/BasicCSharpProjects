﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace _18003959_PROG6212_Task2
{
    /// <summary>
    /// Interaction logic for Student.xaml
    /// </summary>
    public partial class Student : Window
    {
        List<TestClass> test = new List<TestClass>();
        readAndWrite raw = new readAndWrite(); //Class for reading and writing to the database 
        string stuNumber;
        int testID;
        public Student(string id)//Gets current students student number
        {
            InitializeComponent();
            stuNumber = id;
        }

        private void Window_Loaded(object sender, RoutedEventArgs e) //https://stackoverflow.com/questions/2619348/does-form-onload-exist-in-wpf
        {
            test = raw.readFromTest();
            for (int i = 0; i < test.Count; i++)
            {
                cmbTests.Items.Add(test[i].TestName);
            }
        }

        private void BtnTest_Click(object sender, RoutedEventArgs e)
        {
            if (cmbTests.SelectedIndex == -1)
            {
                MessageBox.Show("Please pick a test to continue.");
            }
            else
            {
                for (int i = 0; i < test.Count; i++)//searches list for test picked by user
                {
                    if (cmbTests.SelectedItem.ToString() == test[i].TestName)
                    {
                        testID = test[i].TestID;
                    }
                }
                Test temp = new Test(testID, stuNumber);
                temp.Show();
                this.Hide();
            }
        }

        private void BtnExit_Click(object sender, RoutedEventArgs e)// Exits all programs
        {
            MessageBoxResult result = MessageBox.Show("Are you sure want to exit?", "Test Maker", MessageBoxButton.OKCancel);
            switch (result)
            {
                case MessageBoxResult.OK:
                    App.Current.Shutdown();
                    break;
                case MessageBoxResult.Cancel:

                    break;
            }
        }
    }
}

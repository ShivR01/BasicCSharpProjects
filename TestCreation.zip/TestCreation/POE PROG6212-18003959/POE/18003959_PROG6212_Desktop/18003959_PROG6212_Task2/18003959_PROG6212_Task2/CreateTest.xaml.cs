﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace _18003959_PROG6212_Task2
{
    /// <summary>
    /// Interaction logic for CreateTest.xaml
    /// </summary>
    public partial class CreateTest : Window
    {
        Calculations calc = new Calculations(); //Class with methods for calculations
        readAndWrite raw = new readAndWrite(); //Class for reading and writing to the database
        int testID;
        int questionNum = 1;
        string lecID;
        public CreateTest(int id,string backID)
        {
            InitializeComponent();
            testID = id;
            lecID = backID;
        }

        private void Window_Loaded(object sender, RoutedEventArgs e) //https://stackoverflow.com/questions/2619348/does-form-onload-exist-in-wpf
        {
            lblQuestion.Content = "Question " + Convert.ToString(questionNum);
        }

        private void BtnAddQ_Click(object sender, RoutedEventArgs e)
        {
            int id = 0;
            string question, a, b, c, ans;
            questionNum += 1;
            if (tbQuestion.Text.Equals("") || tbA.Text.Equals("") || tbB.Text.Equals("") || tbC.Text.Equals(""))
            {
                MessageBox.Show("Please enter text on all fields.");
            }
            else {
                question = tbQuestion.Text; a = tbA.Text; b = tbB.Text; c = tbC.Text;//stores question deatails
                ans = checkRbValues(); //stores question deatails
                id = calc.getRandomID();//gets random id for question
                raw.writeToQuestions(id, question, a, b, c, ans, testID);//writes question to database
                lblQuestion.Content = "Question " + Convert.ToString(questionNum);//changes question label to next numbered question
                clearFields();
            }
           
        }

        private void clearFields()//For erasing input after each question
        {
            tbQuestion.Clear();
            tbA.Clear();
            tbB.Clear();
            tbC.Clear();
        }

        private string checkRbValues()
        {
            String ans;

            if (rbA.IsChecked == true)
            {
                ans = tbA.Text;
                return ans;
            }
            else {
                if (rbB.IsChecked == true)
                {
                    ans = tbB.Text;
                    return ans;
                }
                else {
                    ans = tbC.Text;
                    return ans;
                }
            }
        }

        private void BtnExit_Click(object sender, RoutedEventArgs e)// Exits all programs
        {
            MessageBoxResult result = MessageBox.Show("Are you sure want to exit?", "Test Maker", MessageBoxButton.OKCancel);
            switch (result)
            {
                case MessageBoxResult.OK:
                    App.Current.Shutdown();
                    break;
                case MessageBoxResult.Cancel:

                    break;
            }
        }

        private void BtnBack_Click(object sender, RoutedEventArgs e)
        {
            LecturerMenu temp = new LecturerMenu(lecID);//Passes current user to previous screen
            temp.Show();
            this.Hide();
        }
    }
}

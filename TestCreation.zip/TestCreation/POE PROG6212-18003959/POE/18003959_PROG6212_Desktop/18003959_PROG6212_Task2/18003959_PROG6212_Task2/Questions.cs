﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _18003959_PROG6212_Task2
{
    class Questions
    {
        private int qID;
        private string question;
        private string optA;
        private string optB;
        private string optC;
        private string answer;
        private int testID;
        private string stuAnswer;

        public Questions()
        {
        }

        public Questions(string stuAnswer)//Constructor to store students answers only
        {
            this.stuAnswer = stuAnswer;
        }

        public Questions(int qID, string question, string optA, string optB, string optC, string answer, int testID)//Constructor to store all question data
        {
            this.qID = qID;
            this.question = question;
            this.optA = optA;
            this.optB = optB;
            this.optC = optC;
            this.answer = answer;
            this.testID = testID;
        }

        public Questions(string question, string answer, string stuAnswer)//Constructor for memorandum
        {
            this.question = question;
            this.answer = answer;
            this.stuAnswer = stuAnswer;
        }

        public int QID { get => qID; set => qID = value; }
        public string Question { get => question; set => question = value; }
        public string OptA { get => optA; set => optA = value; }
        public string OptB { get => optB; set => optB = value; }
        public string OptC { get => optC; set => optC = value; }
        public string Answer { get => answer; set => answer = value; }
        public int TestID { get => testID; set => testID = value; }
        public string StuAnswer { get => stuAnswer; set => stuAnswer = value; }
    }

}

﻿using DllLogin;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace _18003959_PROG6212_Task2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
      dllLog login = new dllLog(); //calling class from DLL
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btnLec_Click(object sender, RoutedEventArgs e)
        {
            tbUsername.Text = "111";
            tbPass.Password = "George123";
        }

        private void btnStu_Click(object sender, RoutedEventArgs e)
        {
            tbUsername.Text = "18003959";
            tbPass.Password = "Shivaar123";
        }

        private void btnExit_Click(object sender, RoutedEventArgs e)// Exits all programs
        {
            MessageBoxResult result = MessageBox.Show("Are you sure want to exit?", "Test Maker", MessageBoxButton.OKCancel);
            switch (result)
            {
                case MessageBoxResult.OK:
                    App.Current.Shutdown();
                    break;
                case MessageBoxResult.Cancel:
                    
                    break;
            }
        }

        private void btnLog_Click(object sender, RoutedEventArgs e)
        {
            string lecStu;
            lecStu = login.checkLogin(tbUsername.Text, tbPass.Password);//Method to check login details from DLL

            if (lecStu == "lecturer")
            {
                LecturerMenu temp = new LecturerMenu(tbUsername.Text);//Passes current user to next screen
                temp.Show();
                this.Hide();
            }
            else
            {
                if (lecStu == "student")
                {
                    Student temp = new Student(tbUsername.Text);//Passes current user to next screen
                    temp.Show();
                    this.Hide();
                }
            }
            if (lecStu == "invalid")
            {
                MessageBox.Show("Please enter a valid Username and Password.");
            }
        }
    }
}

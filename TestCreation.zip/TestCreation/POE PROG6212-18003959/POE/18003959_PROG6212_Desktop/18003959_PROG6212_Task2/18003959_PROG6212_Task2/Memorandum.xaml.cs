﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace _18003959_PROG6212_Task2
{
    /// <summary>
    /// Interaction logic for Memorandum.xaml
    /// </summary>
    public partial class Memorandum : Window
    {
        List<Questions> memo = new List<Questions>();
        internal Memorandum(List<Questions> m)
        {
            InitializeComponent();
            for (int i = 0; i < m.Count; i++)
            {
                memo.Add(new Questions(m[i].Question, m[i].Answer, m[i].StuAnswer));//Stores relevant data regarding memo display
            }
        }

        private void Window_Loaded(object sender, RoutedEventArgs e) //https://stackoverflow.com/questions/2619348/does-form-onload-exist-in-wpf
        {
            rbMemoDisplay.IsReadOnly = true;
            rbMemoDisplay.Focus(); //Hides textbox cursor
            rbMemoDisplay.AppendText("Memorandum\n\n");
            for (int i = 0; i < memo.Count; i++)
            {
                rbMemoDisplay.AppendText("Question " + (i + 1) + ":\n" + memo[i].Question + "\nCorrect answer:\n" + memo[i].Answer + "\nYour answer:\n" + memo[i].StuAnswer + "\n\n");
            }
        }

        private void BtnExit_Click(object sender, RoutedEventArgs e)// Exits all programs
        {
            MessageBoxResult result = MessageBox.Show("Are you sure want to exit?", "Test Maker", MessageBoxButton.OKCancel);
            switch (result)
            {
                case MessageBoxResult.OK:
                    App.Current.Shutdown();
                    break;
                case MessageBoxResult.Cancel:

                    break;
            }
        }
    }
}

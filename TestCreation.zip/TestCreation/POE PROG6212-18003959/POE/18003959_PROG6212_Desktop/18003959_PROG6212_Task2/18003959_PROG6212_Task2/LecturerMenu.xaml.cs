﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace _18003959_PROG6212_Task2
{
    /// <summary>
    /// Interaction logic for LecturerMenu.xaml
    /// </summary>
    public partial class LecturerMenu : Window
    {
        Calculations calc = new Calculations(); //Class with methods for calculations
        readAndWrite raw = new readAndWrite(); //Class for reading and writing to the database
        String lecID;//for storing current lecturer
        public LecturerMenu(String ID)
        {
            InitializeComponent();
            lecID = ID;
        }

        private void BtnCreate_Click(object sender, RoutedEventArgs e)
        {
            if (tbTestName.Text == "")
            {
                MessageBox.Show("Test needs a name.");
            }
            else
            {
                int testID;
                string testName;

                testID = calc.getRandomID(); //gets an id for test
                testName = tbTestName.Text;

                raw.writeToTest(testID, testName, lecID); //Passes values to class to write to database

                CreateTest temp = new CreateTest(testID,lecID);
                temp.Show();
                this.Hide();
            }
        }

        private void BtnExit_Click(object sender, RoutedEventArgs e)// Exits all programs
        {
            MessageBoxResult result = MessageBox.Show("Are you sure want to exit?", "Test Maker", MessageBoxButton.OKCancel);
            switch (result)
            {
                case MessageBoxResult.OK:
                    App.Current.Shutdown();
                    break;
                case MessageBoxResult.Cancel:

                    break;
            }
        }

        private void BtnView_Click(object sender, RoutedEventArgs e)
        {
            ViewStudents temp = new ViewStudents(lecID);
            temp.Show();
            this.Hide();
        }

        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {
            EditTests temp = new EditTests(lecID);
            temp.Show();
            this.Hide();
        }

        private void BtnAddStu_Click(object sender, RoutedEventArgs e)
        {
            AddStudent temp = new AddStudent(lecID);
            temp.Show();
            this.Hide();
        }
    }
}

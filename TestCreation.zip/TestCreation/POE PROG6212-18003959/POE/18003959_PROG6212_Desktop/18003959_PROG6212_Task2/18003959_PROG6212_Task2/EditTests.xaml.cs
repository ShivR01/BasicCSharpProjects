﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace _18003959_PROG6212_Task2
{
    /// <summary>
    /// Interaction logic for EditTests.xaml
    /// </summary>
    public partial class EditTests : Window
    {
        List<TestClass> test = new List<TestClass>();
        List<Questions> qList = new List<Questions>();
        readAndWrite raw = new readAndWrite(); //Class for reading and writing to the database 
        int testID, qlabel = 0, qPos = 0;
        string lecID;//Variable used when going back to lecturer menu
        public EditTests(string backID)
        {
            InitializeComponent();
            lecID = backID;
        }

        private void Window_Loaded(object sender, RoutedEventArgs e) //https://stackoverflow.com/questions/2619348/does-form-onload-exist-in-wpf
        {
            rbA.IsChecked = true;
            btnNextQ.IsEnabled = false;
            test = raw.readFromTest();
            for (int i = 0; i < test.Count; i++)
            {
                cmbTests.Items.Add(test[i].TestName);
            }
        }

        private void BtnTest_Click(object sender, RoutedEventArgs e)
        {
            if (cmbTests.SelectedIndex == -1)
            {
                MessageBox.Show("Please pick a test to continue.");
            }
            else
            {
                for (int i = 0; i < test.Count; i++)//searches list for test picked by user
                {
                    if (cmbTests.SelectedItem.ToString() == test[i].TestName)
                    {
                        testID = test[i].TestID;
                    }
                }

                qList = raw.readFromQuestions(testID);//Gets all questions from database that match testID
                questionsDisplay();
                btnNextQ.IsEnabled = true;
                btnEditTest.IsEnabled = false;
            }
        }

        private void BtnNextQ_Click(object sender, RoutedEventArgs e)
        {
            int id = 0;
            string question, a, b, c, ans;

            question = tbQuestion.Text; a = tbA.Text; b = tbB.Text; c = tbC.Text;//stores question deatails
            ans = checkRbValues(); //stores question deatails
            id = qList[qPos].QID;
            raw.updateQuestion(id, question, a, b, c, ans, testID);//writes question to database

            qPos += 1;
            questionsDisplay();
        }

        private void BtnExit_Click(object sender, RoutedEventArgs e)// Exits all programs
        {
            MessageBoxResult result = MessageBox.Show("Are you sure want to exit?", "Test Maker", MessageBoxButton.OKCancel);
            switch (result)
            {
                case MessageBoxResult.OK:
                    App.Current.Shutdown();
                    break;
                case MessageBoxResult.Cancel:

                    break;
            }
        }

        private void BtnBack_Click(object sender, RoutedEventArgs e)
        {
            LecturerMenu temp = new LecturerMenu(lecID);//Passes current user to previous screen
            temp.Show();
            this.Hide();
        }

        public void questionsDisplay()
        {
            if (qPos == qList.Count)//Stops test when questions reach an end
            {
                btnNextQ.IsEnabled = false;
                MessageBox.Show("There are no more questions to edit.");
            }
            else//Displays next question
            {
                qlabel += 1;
                lblQuestion.Content = "Question " + Convert.ToString(qlabel) + ":";

                tbQuestion.Text = qList[qPos].Question;
                tbA.Text = qList[qPos].OptA;
                tbB.Text = qList[qPos].OptB;
                tbC.Text = qList[qPos].OptC;
            }
        }

        private void btnDeleteTest_Click(object sender, RoutedEventArgs e)
        {
            if (cmbTests.SelectedIndex == -1)
            {
                MessageBox.Show("Please pick a test to continue.");
            }
            else
            {
                MessageBoxResult messageBoxResult = MessageBox.Show("Deleting this test will delete all of its questions and student answers. Would you still like to continue?", "Delete Confirmation", MessageBoxButton.YesNo);
                if (messageBoxResult == MessageBoxResult.Yes)
                {
                    for (int i = 0; i < test.Count; i++)//searches list for test picked by user
                    {
                        if (cmbTests.SelectedItem.ToString() == test[i].TestName)
                        {
                            testID = test[i].TestID;
                        }
                    }
                    raw.deleteAllTestData(testID);
                }
               

                qList = raw.readFromQuestions(testID);//Gets all questions from database that match testID
                questionsDisplay();
                btnEditTest.IsEnabled = false;
            }
        }

        private string checkRbValues()
        {
            String ans;

            if (rbA.IsChecked == true)
            {
                ans = tbA.Text;
                return ans;
            }
            else
            {
                if (rbB.IsChecked == true)
                {
                    ans = tbB.Text;
                    return ans;
                }
                else
                {
                    ans = tbC.Text;
                    return ans;
                }
            }
        }
    }
}

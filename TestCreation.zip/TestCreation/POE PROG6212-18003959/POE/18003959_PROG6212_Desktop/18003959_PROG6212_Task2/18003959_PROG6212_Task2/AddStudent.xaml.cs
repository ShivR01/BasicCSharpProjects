﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Text.RegularExpressions;

namespace _18003959_PROG6212_Task2
{
    /// <summary>
    /// Interaction logic for AddStudent.xaml
    /// </summary>
    public partial class AddStudent : Window
    {
        string lecID;
        readAndWrite raw = new readAndWrite(); //Class for reading and writing to the database
        public AddStudent(string id)
        {
            InitializeComponent();
            lecID = id;
        }

        private void BtnAddStu_Click(object sender, RoutedEventArgs e)
        {
            if ((tbStuNum.Text == "") || (tbFname.Text == "") || (tbLname.Text == "") || (tbPass.Text == ""))
            {
                MessageBox.Show("Please enter all fields.");
            }
            else
            {
                if (dpAge.SelectedDate.Equals(null))
                {
                    MessageBox.Show("please enter a date of birth for student.");
                }
                else
                {
                    int currentDate = Convert.ToInt16(DateTime.Now.Year);
                    int birthYear = Convert.ToInt16(dpAge.SelectedDate.Value.Year);
                    int age = currentDate - birthYear;

                    raw.writeToStudent(tbStuNum.Text,tbFname.Text,tbLname.Text,age,tbPass.Text);
                    clearFields();
                }
            }

            
        }
    
        private void NumberValidationTextBox(object sender, TextCompositionEventArgs e) //Code used from https://stackoverflow.com/questions/1268552/how-do-i-get-a-textbox-to-only-accept-numeric-input-in-wpf
        {
            Regex regex = new Regex("[^0-9]+"); //Prevent letters from being inputted in the student number textbox
            e.Handled = regex.IsMatch(e.Text);
        }

        private void LetterValidationTextBox(object sender, TextCompositionEventArgs e) //Code used from https://stackoverflow.com/questions/1268552/how-do-i-get-a-textbox-to-only-accept-numeric-input-in-wpf
        {
            Regex regex = new Regex("[^a-zA-Z]+"); //Prevents numbers from being inputted into the first and last name text boxes
            e.Handled = regex.IsMatch(e.Text);
        }

        private void BtnExit_Click(object sender, RoutedEventArgs e)
        {
            MessageBoxResult result = MessageBox.Show("Are you sure want to exit?", "Test Maker", MessageBoxButton.OKCancel);
            switch (result)
            {
                case MessageBoxResult.OK:
                    App.Current.Shutdown();
                    break;
                case MessageBoxResult.Cancel:

                    break;
            }
        }

        private void BtnBack_Click(object sender, RoutedEventArgs e)
        {
            LecturerMenu temp = new LecturerMenu(lecID);//Passes current user to previous screen
            temp.Show();
            this.Hide();
        }

        public void clearFields()
        {
            tbStuNum.Text = "";
            tbFname.Text = "";
            tbLname.Text = "";
            tbPass.Text = "1111";
            dpAge.SelectedDate = null;
        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace _18003959_PROG6212_Task2
{
    /// <summary>
    /// Interaction logic for ViewStudents.xaml
    /// </summary>
    public partial class ViewStudents : Window
    {
        readAndWrite raw = new readAndWrite();
        List<TestClass> test_student = new List<TestClass>();
        string lecID;
        public ViewStudents(string backID)
        {
            InitializeComponent();
            lecID = backID;
        }

        private void Window_Loaded(object sender, RoutedEventArgs e) //https://stackoverflow.com/questions/2619348/does-form-onload-exist-in-wpf
        {
            rbDisplay.IsReadOnly = true;
            rbDisplay.Document.Blocks.Clear();
            test_student = raw.readFromTest_Student();
            rbDisplay.Focus();
            rbDisplay.AppendText("Students and Results\n\n");
            for (int i = 0; i < test_student.Count; i++) //Displays all students and all the tests they have taken
            {
                rbDisplay.AppendText("Student Number: " + test_student[i].StuNum + "\nResult: " + test_student[i].Results + "\nTest ID: " + test_student[i].TestID + "\n\n");
            }
        }

        private void BtnExit_Click(object sender, RoutedEventArgs e)// Exits all programs
        {
            MessageBoxResult result = MessageBox.Show("Are you sure want to exit?", "Test Maker", MessageBoxButton.OKCancel);
            switch (result)
            {
                case MessageBoxResult.OK:
                    App.Current.Shutdown();
                    break;
                case MessageBoxResult.Cancel:

                    break;
            }
        }

        private void BtnBack_Click(object sender, RoutedEventArgs e)
        {
            LecturerMenu temp = new LecturerMenu(lecID);//Passes current user to previous screen
            temp.Show();
            this.Hide();
        }
    }
}

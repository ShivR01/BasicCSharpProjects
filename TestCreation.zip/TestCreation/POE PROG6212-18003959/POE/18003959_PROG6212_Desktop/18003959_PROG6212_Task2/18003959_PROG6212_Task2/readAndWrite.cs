﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace _18003959_PROG6212_Task2
{
    class readAndWrite
    {
        public void writeToTest(int id, string name, string lec)//Stores new test created by lecturer
        {
            try
            {
                using (SqlConnection con = new SqlConnection(Properties.Settings.Default.ConString))
                {
                    string sqlQuery = "Insert into test (testID, testName, lecID) VALUES (@testID,@testName,@lecID);";
                    con.Open();
                    using (SqlCommand cmd = new SqlCommand(sqlQuery, con))
                    {
                        cmd.Parameters.AddWithValue("@testID", id);
                        cmd.Parameters.AddWithValue("@testName", name);
                        cmd.Parameters.AddWithValue("@lecID", lec);
                        cmd.ExecuteNonQuery();

                        if (con.State == ConnectionState.Open)
                            con.Close();
                        MessageBox.Show("Test added succesfully");
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        public void writeToQuestions(int id, string q, string a, string b, string c, string ans, int tId)//Stores new question created by lecturer
        {
            try
            {
                using (SqlConnection con = new SqlConnection(Properties.Settings.Default.ConString))
                {
                    string sqlQuery = "Insert into questions (qID, question, A, B, C, answer, testID) VALUES (@qID,@question,@A,@B,@C,@answer,@testID);";
                    con.Open();
                    using (SqlCommand cmd = new SqlCommand(sqlQuery, con))
                    {
                        cmd.Parameters.AddWithValue("@qID", id);
                        cmd.Parameters.AddWithValue("@question", q);
                        cmd.Parameters.AddWithValue("@A", a);
                        cmd.Parameters.AddWithValue("@B", b);
                        cmd.Parameters.AddWithValue("@C", c);
                        cmd.Parameters.AddWithValue("@answer", ans);
                        cmd.Parameters.AddWithValue("@testID", tId);
                        cmd.ExecuteNonQuery();

                        if (con.State == ConnectionState.Open)
                            con.Close();
                        MessageBox.Show("Question added succesfully");
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        public void writeToTest_Student(int id, int r, int tid, string num)//Stores to results in database
        {
            try
            {
                using (SqlConnection con = new SqlConnection(Properties.Settings.Default.ConString))
                {
                    string sqlQuery = "Insert into test_student (test_studentID, results, testID, stuNumber) VALUES (@test_studentID,@results,@testID,@stuNumber);";
                    con.Open();
                    using (SqlCommand cmd = new SqlCommand(sqlQuery, con))
                    {
                        cmd.Parameters.AddWithValue("@test_studentID", id);
                        cmd.Parameters.AddWithValue("@results", r);
                        cmd.Parameters.AddWithValue("@testID", tid);
                        cmd.Parameters.AddWithValue("@stuNumber", num);
                        cmd.ExecuteNonQuery();

                        if (con.State == ConnectionState.Open)
                            con.Close();
                        MessageBox.Show("Results added succesfully");
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        public void writeToStudent(string sn, string f,string l, int a, string pass)//For writing to students table
        {
            try
            {
                using (SqlConnection con = new SqlConnection(Properties.Settings.Default.ConString))
                {
                    string sqlQuery = "Insert into student (stuNumber, fName, lName, age, stuPassword) VALUES (@stuNumber,@fName,@lName,@age,@stuPassword);";
                    con.Open();
                    using (SqlCommand cmd = new SqlCommand(sqlQuery, con))
                    {
                        cmd.Parameters.AddWithValue("@stuNumber", sn);
                        cmd.Parameters.AddWithValue("@fName", f);
                        cmd.Parameters.AddWithValue("@lName", l);
                        cmd.Parameters.AddWithValue("@age", a);
                        cmd.Parameters.AddWithValue("@stuPassword", pass);
                        cmd.ExecuteNonQuery();

                        if (con.State == ConnectionState.Open)
                            con.Close();
                        MessageBox.Show("User added succesfully");
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        public List<TestClass> readFromTest()//Gets all values from test table and returns a list of object with all the data
        {
            List<TestClass> test = new List<TestClass>();

            try
            {
                using (SqlConnection con = new SqlConnection(Properties.Settings.Default.ConString))//Gets all test values
                {
                    string sqlQuery = "Select * from test";
                    con.Open();
                    using (SqlCommand cmd = new SqlCommand(sqlQuery, con))
                    {
                        SqlDataReader dataReader = cmd.ExecuteReader();
                        while (dataReader.Read())
                        {
                            test.Add(new TestClass(Convert.ToInt16(dataReader.GetValue(0)), dataReader.GetString(1), dataReader.GetString(2)));
                        }

                        dataReader.Close();
                        if (con.State == ConnectionState.Open)
                            con.Close();
                        cmd.Dispose();
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }

            return test;
        }

        public List<TestClass> readFromTest_Student()//Gets all values from test_Student table and returns a list of object with all the data
        {
            List<TestClass> testStu = new List<TestClass>();

            try
            {
                using (SqlConnection con = new SqlConnection(Properties.Settings.Default.ConString))//Gets all test values
                {
                    string sqlQuery = "Select * from test_student";
                    con.Open();
                    using (SqlCommand cmd = new SqlCommand(sqlQuery, con))
                    {
                        SqlDataReader dataReader = cmd.ExecuteReader();
                        while (dataReader.Read())
                        {
                            testStu.Add(new TestClass(dataReader.GetString(3), Convert.ToInt16(dataReader.GetValue(1)), Convert.ToInt16(dataReader.GetValue(2))));
                        }

                        dataReader.Close();
                        if (con.State == ConnectionState.Open)
                            con.Close();
                        cmd.Dispose();
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }

            return testStu;
        }

        public List<Questions> readFromQuestions(int selectedTestID)//Gets all values from questions table and returns a list of object with all the data
        {
            List<Questions> allQuestions = new List<Questions>();//Used to store all questions
            List<Questions> selectedTestQuestions = new List<Questions>();//Used to store questions from user selected test

            try
            {
                using (SqlConnection con = new SqlConnection(Properties.Settings.Default.ConString))//Gets all question values
                {
                    string sqlQuery = "Select * from questions";
                    con.Open();
                    using (SqlCommand cmd = new SqlCommand(sqlQuery, con))
                    {
                        SqlDataReader dataReader = cmd.ExecuteReader();
                        while (dataReader.Read())
                        {
                            allQuestions.Add(new Questions(Convert.ToInt16(dataReader.GetValue(0)), dataReader.GetString(1), dataReader.GetString(2), dataReader.GetString(3), dataReader.GetString(4), dataReader.GetString(5), Convert.ToInt16(dataReader.GetValue(6))));
                        }

                        dataReader.Close();
                        if (con.State == ConnectionState.Open)
                            con.Close();
                        cmd.Dispose();
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }

            for (int i = 0; i < allQuestions.Count; i++)//sorts through allQuestions list to find questions relating to the test the user chose
            {
                if (allQuestions[i].TestID == selectedTestID)
                {
                    selectedTestQuestions.Add(new Questions(allQuestions[i].QID, allQuestions[i].Question, allQuestions[i].OptA, allQuestions[i].OptB, allQuestions[i].OptC, allQuestions[i].Answer, allQuestions[i].TestID));
                }
            }

            return selectedTestQuestions;
        }

        public void updateQuestion(int id, string q, string a, string b, string c, string ans, int tId)
        {
            try
            {
                SqlConnection con = new SqlConnection(Properties.Settings.Default.ConString);
                con.Open();
                string sqlQuery = "Update questions set qID=@qID, " + "question=@question," + "A=@A," + "B=@B," + "C=@C," + "answer=@answer," + "testID=@testID" + " WHERE qID=@qID";
                using (SqlCommand cmd = new SqlCommand(sqlQuery, con))
                {
                    cmd.Parameters.AddWithValue("@qID", id);
                    cmd.Parameters.AddWithValue("@question", q);
                    cmd.Parameters.AddWithValue("@A", a);
                    cmd.Parameters.AddWithValue("@B", b);
                    cmd.Parameters.AddWithValue("@C", c);
                    cmd.Parameters.AddWithValue("@answer", ans);
                    cmd.Parameters.AddWithValue("@testID", tId);

                    cmd.ExecuteNonQuery();

                    if (con.State == ConnectionState.Open)
                        con.Close();
                    MessageBox.Show("Question updated successfully");
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        public void deleteAllTestData(int id) //Deletes test aswell as all its traces within the database
        {
            try
            {
                SqlConnection con = new SqlConnection(Properties.Settings.Default.ConString);
                con.Open();
                string sqlQuery = "Delete From test_student WHERE testID=@tID";
                using (SqlCommand cmd = new SqlCommand(sqlQuery, con))
                {
                    cmd.Parameters.AddWithValue("@tID", id);

                    cmd.ExecuteNonQuery();

                    if (con.State == ConnectionState.Open)
                        con.Close();
                }
            }
            catch (Exception)
            {
                throw;
            }

            try
            {
                SqlConnection con = new SqlConnection(Properties.Settings.Default.ConString);
                con.Open();
                string sqlQuery = "Delete From questions WHERE testID=@tID";
                using (SqlCommand cmd = new SqlCommand(sqlQuery, con))
                {
                    cmd.Parameters.AddWithValue("@tID", id);

                    cmd.ExecuteNonQuery();

                    if (con.State == ConnectionState.Open)
                        con.Close();
                }
            }
            catch (Exception)
            {
                throw;
            }

            try
            {
                SqlConnection con = new SqlConnection(Properties.Settings.Default.ConString);
                con.Open();
                string sqlQuery = "Delete From test WHERE testID=@tID";
                using (SqlCommand cmd = new SqlCommand(sqlQuery, con))
                {
                    cmd.Parameters.AddWithValue("@tID", id);

                    cmd.ExecuteNonQuery();

                    if (con.State == ConnectionState.Open)
                        con.Close();
                    MessageBox.Show("Test and its data deleted successfully");
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}

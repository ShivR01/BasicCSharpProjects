﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;

namespace _18003959_PROG6212_Task2
{
    class Calculations
    {
        public int getRandomID()  // code used from https://stackoverflow.com/questions/2706500/how-do-i-generate-a-random-int-number
        {
            Random rnd = new Random();
            int randID = rnd.Next(2, 999);
            return randID;
        }

        public int calculateResults(List<Questions> stuAns, List<Questions> Ans)//Calculates students correct choices for test and returns the result
        {
            int Result = 0;

            for (int i = 0; i < stuAns.Count; i++)
            {
                if (stuAns[i].StuAnswer == Ans[i].Answer)
                {
                    Result += 1;
                }
            }

            MessageBox.Show("Your Result = " + Result + "/" + stuAns.Count+" " + "Click ok to view memorandum");
            return Result;
        }

        public List<Questions> sortForMemo(List<Questions> stuAns, List<Questions> Ans)//Returns List of objects for memo displaying
        {
            List<Questions> memo = new List<Questions>();
            for (int i = 0; i < stuAns.Count; i++)
            {
                memo.Add(new Questions(Ans[i].Question, Ans[i].Answer, stuAns[i].StuAnswer));
            }

            return memo;
        }
    }
}

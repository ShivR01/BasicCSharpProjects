﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace _18003959_PROG6212_Task2
{
    /// <summary>
    /// Interaction logic for Test.xaml
    /// </summary>
    public partial class Test : Window
    {
        int testID, qlabel = 0, qPos = 0;
        string stuNumber;
        List<Questions> testQuestions = new List<Questions>();
        List<Questions> stuAnswers = new List<Questions>();
        readAndWrite raw = new readAndWrite(); //Class for reading and writing to the database 
        Calculations calc = new Calculations(); //Class for all calulations
        public Test(int tID, string num)
        {
            InitializeComponent();
            testID = tID;
            stuNumber = num;
        }

        private void BtnResults_Click(object sender, RoutedEventArgs e)
        {
            List<Questions> memo = new List<Questions>();
            int Results;
            Results = calc.calculateResults(stuAnswers, testQuestions);
            raw.writeToTest_Student(calc.getRandomID(), Results, testID, stuNumber);       
            memo = calc.sortForMemo(stuAnswers, testQuestions);
            Memorandum temp = new Memorandum(memo);
            temp.Show();
            this.Hide();
        }

        private void BtnNextQ_Click(object sender, RoutedEventArgs e)
        {
            stuAnswers.Add(new Questions(tbAns.Text));
            qPos += 1;
            questionsDisplay();
            tbAns.Clear();
        }

        private void BtnExit_Click(object sender, RoutedEventArgs e)// Exits all programs
        {
            MessageBoxResult result = MessageBox.Show("Are you sure want to exit?", "Test Maker", MessageBoxButton.OKCancel);
            switch (result)
            {
                case MessageBoxResult.OK:
                    App.Current.Shutdown();
                    break;
                case MessageBoxResult.Cancel:

                    break;
            }
        }

        private void Window_Loaded(object sender, RoutedEventArgs e) //https://stackoverflow.com/questions/2619348/does-form-onload-exist-in-wpf
        {
            rbOptA.IsChecked = true;
            btnResults.Visibility = Visibility.Hidden;
            testQuestions = raw.readFromQuestions(testID);
            questionsDisplay();
        }

        public void questionsDisplay()
        {
            if (qPos == testQuestions.Count)//Stops test when questions reach an end
            {
                btnNextQ.IsEnabled = false;
                MessageBox.Show("Test completed! Please wait while we calculate your results.");
                btnResults.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));
            }
            else//Displays next question
            {
                qlabel += 1;
                lblQuestion.Content = "Question " + Convert.ToString(qlabel) + ":";
                tbDisplay.Text = testQuestions[qPos].Question;
                rbOptA.Content = testQuestions[qPos].OptA;
                rbOptB.Content = testQuestions[qPos].OptB;
                rbOptC.Content = testQuestions[qPos].OptC;
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _18003959_PROG6212_Task2
{
    class TestClass
    {
        private int testID;
        private string testName;
        private string lecID;

        private int test_studentID;
        private int results;
        private String stuNum;

        public int TestID { get => testID; set => testID = value; }
        public string TestName { get => testName; set => testName = value; }
        public string LecID { get => lecID; set => lecID = value; }
        public int Test_studentID { get => test_studentID; set => test_studentID = value; }
        public int Results { get => results; set => results = value; }
        public string StuNum { get => stuNum; set => stuNum = value; }

        public TestClass(int testID, string testName, string lecID)
        {
            this.testID = testID;
            this.testName = testName;
            this.lecID = lecID;
        } 

        public TestClass()
        {

        }

        public TestClass(string stuNum, int results, int testID)
        {
            this.stuNum = stuNum;
            this.results = results;
            this.testID = testID;
        }
    }
}

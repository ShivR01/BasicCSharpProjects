﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DllLogin
{
    public class dllLog
    {
        List<String> lecID = new List<String>();
        List<String> lecPassword = new List<String>();          //Lists for storing student and lecturer details
        List<String> stuNumber = new List<String>();
        List<String> stuPassword = new List<String>();

        public string checkLogin(string username, string password)
        {
            string validOrInvalid = "";
            int flag = 1;
            try
            {
                using (SqlConnection con = new SqlConnection(Properties.Settings.Default.ConString))//Gets the all the values for username and pass for lecturers in the database
                {
                    string sqlQuery = "select * from lecturer";
                    con.Open();
                    using (SqlCommand cmd = new SqlCommand(sqlQuery, con))
                    {
                        SqlDataReader dataReader = cmd.ExecuteReader();
                        while (dataReader.Read())
                        {
                            lecID.Add(dataReader.GetString(0));
                            lecPassword.Add(dataReader.GetString(4));
                        }

                        dataReader.Close();
                        if (con.State == ConnectionState.Open)
                            con.Close();
                        cmd.Dispose();
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }

            try
            {
                using (SqlConnection con = new SqlConnection(Properties.Settings.Default.ConString))//Gets the all the values for username and pass for students in the database
                {
                    string sqlQuery = "select * from student";
                    con.Open();
                    using (SqlCommand cmd = new SqlCommand(sqlQuery, con))
                    {
                        SqlDataReader dataReader = cmd.ExecuteReader();
                        while (dataReader.Read())
                        {
                            stuNumber.Add(dataReader.GetString(0));
                            stuPassword.Add(dataReader.GetString(4));
                        }

                        dataReader.Close();
                        if (con.State == ConnectionState.Open)
                            con.Close();
                        cmd.Dispose();
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }

            for (int i = 0; i < lecID.Count; i++)
            {
                if ((lecID[i] == username) && (lecPassword[i] == password))//If details match lecturers then a string with value lecturer will be returned
                {
                    flag = 0;
                    validOrInvalid = "lecturer";
                    break;
                }
            }
            for (int i = 0; i < stuNumber.Count; i++)
            {
                if ((stuNumber[i] == username) && (stuPassword[i] == password))// If details match students then a string with value student will be returned
                {
                    flag = 0;
                    validOrInvalid = "student";
                    break;
                }
            }
            if (flag > 0)//if none match then invalid will be returned
            {
                validOrInvalid = "invalid";
            }

            return validOrInvalid;
        }
    }
}

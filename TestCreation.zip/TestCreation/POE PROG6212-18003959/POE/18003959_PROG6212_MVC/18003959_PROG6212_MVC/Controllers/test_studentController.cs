﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using _18003959_PROG6212_MVC;

namespace _18003959_PROG6212_MVC.Controllers
{
    public class test_studentController : Controller
    {
        private TestMakerEntities db = new TestMakerEntities();

        // GET: test_student
        public ActionResult lecStu(int? id)
        {
            if (Session["Username"] == null)
            {
                Session["Error message"] = "You need to login first";
                return RedirectToAction("Login", "lecturers");
            }
            else
            {//Displays all students that took the chosen test
                List<test_student> ts = new List<test_student>();
                foreach (test_student item in db.test_student)
                {
                    if (item.testID.Equals(id))
                    {
                        test_student testStu = db.test_student.Find(item.test_studentID);
                        ts.Add(testStu);
                    }
                }
                return View(ts.ToList());
            }
           
        }

        // GET: test_student/Details/5
        public ActionResult Details(int? id)
        {
            if (Session["Username"] == null)
            {
                Session["Error message"] = "You need to login first";
                return RedirectToAction("Login", "lecturers");
            }
            else
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }
                test_student test_student = db.test_student.Find(id);
                if (test_student == null)
                {
                    return HttpNotFound();
                }
                return View(test_student);
            }
           
        }

        // GET: test_student/Edit/5
        public ActionResult Edit(int? id)
        {
            if (Session["Username"] == null)
            {
                Session["Error message"] = "You need to login first";
                return RedirectToAction("Login", "lecturers");
            }
            else
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }
                test_student test_student = db.test_student.Find(id);
                if (test_student == null)
                {
                    return HttpNotFound();
                }
                ViewBag.stuNumber = new SelectList(db.students, "stuNumber", "stuNumber", test_student.stuNumber);
                ViewBag.testID = new SelectList(db.tests, "testID", "testName", test_student.testID);
                return View(test_student);
            }
           
        }

        // POST: test_student/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "test_studentID,results,testID,stuNumber")] test_student test_student)
        {
            if (ModelState.IsValid)
            {
                db.Entry(test_student).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("lecStu",new {id = test_student.testID });
            }
            ViewBag.stuNumber = new SelectList(db.students, "stuNumber", "stuNumber", test_student.stuNumber);
            ViewBag.testID = new SelectList(db.tests, "testID", "testName", test_student.testID);
            return View(test_student);
        }

        // GET: test_student/Delete/5
        public ActionResult Delete(int? id)
        {
            if (Session["Username"] == null)
            {
                Session["Error message"] = "You need to login first";
                return RedirectToAction("Login", "lecturers");
            }
            else
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }
                test_student test_student = db.test_student.Find(id);
                if (test_student == null)
                {
                    return HttpNotFound();
                }
                return View(test_student);
            }
          
        }

        // POST: test_student/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            test_student test_student = db.test_student.Find(id);
            db.test_student.Remove(test_student);
            db.SaveChanges();
            return RedirectToAction("lecStu");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}

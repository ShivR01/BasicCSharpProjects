﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using _18003959_PROG6212_MVC;

namespace _18003959_PROG6212_MVC.Controllers
{
    public class studentsController : Controller
    {
        private TestMakerEntities db = new TestMakerEntities();

        // GET: students
        public ActionResult StudentProfile(string id)
        {
            if (Session["Username"] == null)//Checks if any user is logged in
            {
                Session["Error message"] = "You need to login first";
                return RedirectToAction("Login", "lecturers");
            }
            else
            {//Displays currently signed in students details
                List<student> s = new List<student>();
                foreach (student item in db.students)
                {
                    if (item.stuNumber.Equals(id))
                    {
                        student stu = db.students.Find(item.stuNumber);
                        s.Add(stu);
                    }
                }
                return View(s.ToList());
            }
           
        }

        // GET: students/Edit/5
        public ActionResult Edit(string id)
        {
            if (Session["Username"] == null)//Checks if any user is logged in
            {
                Session["Error message"] = "You need to login first";
                return RedirectToAction("Login", "lecturers");
            }
            else
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }
                student student = db.students.Find(id);
                if (student == null)
                {
                    return HttpNotFound();
                }
                return View(student);
            }
           
        }

        // POST: students/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "stuNumber,fName,lName,age,stuPassword")] student student)
        {
            if (ModelState.IsValid)
            {
                db.Entry(student).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("StudentProfile", new {id = student.stuNumber });
            }
            return View(student);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using _18003959_PROG6212_MVC;

namespace _18003959_PROG6212_MVC.Controllers
{
    public class StudentMarksController : Controller
    {
        private TestMakerEntities db = new TestMakerEntities();

        // GET: StudentMarks
        public ActionResult StuMarks(string id)
        {
            if (Session["Username"] == null)
            {
                Session["Error message"] = "You need to login first";
                return RedirectToAction("Login", "lecturers");
            }
            else
            {//Displays student marks for current student logged in
                List<test_student> s = new List<test_student>();
                foreach (test_student item in db.test_student)
                {
                    if (item.stuNumber.Equals(id))
                    {
                        test_student stu = db.test_student.Find(item.test_studentID);
                        s.Add(stu);
                    }
                }
                return View(s.ToList());
            }
           
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}

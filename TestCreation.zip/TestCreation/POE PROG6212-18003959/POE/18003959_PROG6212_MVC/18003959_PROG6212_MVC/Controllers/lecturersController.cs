﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using _18003959_PROG6212_MVC;

namespace _18003959_PROG6212_MVC.Controllers
{
    public class lecturersController : Controller
    {
        private TestMakerEntities db = new TestMakerEntities();

        // GET: lecturers
        public ActionResult Lecturer(string id)
        {
            if (Session["Username"] == null)//Checks if any user is logged in
            {
                Session["Error message"] = "You need to login first";
                return RedirectToAction("Login", "lecturers");
            }
            else
            {//Displays currently signed in Lecturer details
                List<lecturer> L = new List<lecturer>();
                foreach (lecturer item in db.lecturers)
                {
                    if (item.lecID.Equals(id))
                    {
                        lecturer lec = db.lecturers.Find(item.lecID);
                        L.Add(lec);
                    }
                }
                return View(L.ToList());
            }
        }

        public ActionResult Logout() // Applications logs user out and brings them to the home screen
        {
            FormsAuthentication.SignOut();
            Session.Clear();
            return RedirectToAction("Index", "Home");
        }

        public ActionResult Login()//Checks if any user is logged in
        {
            if (Session["Error messsage"] == null)
            {
                ViewBag.Error = Session["Error message"] as string;
            }
            return View();

        }
        [HttpPost]
        public ActionResult Login(string tbUsername, string tbPassword)
        {
            bool found = false;
            foreach (lecturer u in db.lecturers)//Checks each lecturer in database
            {
                if (tbUsername.Equals(u.lecID) && (tbPassword.Equals(u.lecPassword)))//Checks if details entered by the user matches details in database
                {
                    found = true;
                    Session["Username"] = tbUsername; //sets session to current users username
                    return RedirectToAction("Lecturer", new {id = tbUsername });
                }
            }
            if (!found)//If details entered by user does not match any lecturers details then check student table
            {
                foreach (student s in db.students)
                {
                    if (tbUsername.Equals(s.stuNumber) && (tbPassword.Equals(s.stuPassword)))
                    {
                        found = true;
                        Session["Username"] = tbUsername;
                        return RedirectToAction("StudentProfile","students", new {id = tbUsername});
                    }
                }
                if (!found)
                {
                    ViewBag.Error = ("Incorrect password or username");
                }
            }
            return View();
        }

        public ActionResult Success()//Error message for unauthorised access to pages without signing in first
        {
            if (Session["Username"] == null)
            {
                Session["Error message"] = "You need to login first";
                return RedirectToAction("Login");
            }
            else
            {
                return View();
            }
        }

        // GET: lecturers/Edit/5
        public ActionResult Edit(string id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            lecturer lecturer = db.lecturers.Find(id);
            if (lecturer == null)
            {
                return HttpNotFound();
            }
            return View(lecturer);
        }

        // POST: lecturers/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "lecID,fName,lName,age,lecPassword")] lecturer lecturer)
        {
            if (ModelState.IsValid)
            {
                db.Entry(lecturer).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Lecturer",new {id = lecturer.lecID });
            }
            return View(lecturer);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

    }
}

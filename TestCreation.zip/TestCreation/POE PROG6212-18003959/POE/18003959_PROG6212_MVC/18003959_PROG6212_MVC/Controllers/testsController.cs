﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using _18003959_PROG6212_MVC;

namespace _18003959_PROG6212_MVC.Controllers
{
    public class testsController : Controller
    {
        private TestMakerEntities db = new TestMakerEntities();

        // GET: tests
        public ActionResult allTest()
        {
            if (Session["Username"] == null)
            {
                Session["Error message"] = "You need to login first";
                return RedirectToAction("Login", "lecturers");
            }
            else
            {
                var tests = db.tests.Include(t => t.lecturer);
                return View(tests.ToList());
            }
        }

        // GET: tests/Create
        public ActionResult Create()
        {
            if (Session["Username"] == null)
            {
                Session["Error message"] = "You need to login first";
                return RedirectToAction("Login", "lecturers");
            }
            else
            {
                ViewBag.lecID = new SelectList(db.lecturers, "lecID", "lecID");
                return View();
            }

        }

        // POST: tests/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "testID,testName,lecID")] test test)
        {
            if (ModelState.IsValid)
            {
                db.tests.Add(test);
                db.SaveChanges();
                return RedirectToAction("allTest"); 
            }

            ViewBag.lecID = new SelectList(db.lecturers, "lecID", "lecID", test.lecID);
            return View(test);
        }

        // GET: tests/Edit/5
        public ActionResult Edit(int? id)
        {
            if (Session["Username"] == null)
            {
                Session["Error message"] = "You need to login first";
                return RedirectToAction("Login", "lecturers");
            }
            else
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }
                test test = db.tests.Find(id);
                if (test == null)
                {
                    return HttpNotFound();
                }
                ViewBag.lecID = new SelectList(db.lecturers, "lecID", "fName", test.lecID);
                return View(test);
            }
           
        }

        // POST: tests/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "testID,testName,lecID")] test test)
        {
            if (ModelState.IsValid)
            {
                db.Entry(test).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("allTest");
            }
            ViewBag.lecID = new SelectList(db.lecturers, "lecID", "fName", test.lecID);
            return View(test);
        }

        // GET: tests/Delete/5
        public ActionResult Delete(int? id)
        {
            if (Session["Username"] == null)
            {
                Session["Error message"] = "You need to login first";
                return RedirectToAction("Login", "lecturers");
            }
            else
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }
                test test = db.tests.Find(id);
                if (test == null)
                {
                    return HttpNotFound();
                }
                return View(test);
            }      
        }

        // POST: tests/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            test test = db.tests.Find(id);
            db.tests.Remove(test);
            foreach (question item in db.questions)//Deletes all quetions with matching test ID
            {
                if (item.testID.Equals(id))
                {
                    question quest = db.questions.Find(item.qID);
                    db.questions.Remove(quest);
                }
            }
            foreach (test_student item in db.test_student)//Deletes all students test results with matching test ID
            {
                if (item.testID.Equals(id))
                {
                    test_student ts = db.test_student.Find(item.test_studentID);
                    db.test_student.Remove(ts);
                }
            }
            db.SaveChanges();
            return RedirectToAction("allTest");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using _18003959_PROG6212_MVC;

namespace _18003959_PROG6212_MVC.Controllers
{
    public class questionsController : Controller
    {
        private TestMakerEntities db = new TestMakerEntities();

        // GET: questions
        public ActionResult Questions(int? id)
        {
            if (Session["Username"] == null)//Checks if any user is logged in
            {
                Session["Error message"] = "You need to login first";
                return RedirectToAction("Login", "lecturers");
            }
            else
            {//Displays questions realting to test the user chose
                List<question> q = new List<question>();
                foreach (question item in db.questions)
                {
                    if (item.testID.Equals(id))
                    {
                        question questions = db.questions.Find(item.qID);
                        q.Add(questions);
                    }
                }
                return View(q.ToList());
            }
           
        }

        // GET: questions/Details/5
        public ActionResult Details(int? id)
        {
            if (Session["Username"] == null)//Checks if any user is logged in
            {
                Session["Error message"] = "You need to login first";
                return RedirectToAction("Login", "lecturers");
            }
            else
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }
                question question = db.questions.Find(id);
                if (question == null)
                {
                    return HttpNotFound();
                }
                return View(question);
            }
        }

        // GET: questions/Create
        public ActionResult Create()
        {
            if (Session["Username"] == null)//Checks if any user is logged in
            {
                Session["Error message"] = "You need to login first";
                return RedirectToAction("Login", "lecturers");
            }
            else
            {
                ViewBag.testID = new SelectList(db.tests, "testID", "testName");
                return View();
            }
           
        }

        // POST: questions/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "qID,question1,A,B,C,answer,testID")] question question)
        {
            if (ModelState.IsValid)
            {
                db.questions.Add(question);
                db.SaveChanges();
                return RedirectToAction("Questions", new {id = question.testID });
            }

            ViewBag.testID = new SelectList(db.tests, "testID", "testName", question.testID);
            return View(question);
        }

        // GET: questions/Edit/5
        public ActionResult Edit(int? id)
        {
            if (Session["Username"] == null)//Checks if any user is logged in
            {
                Session["Error message"] = "You need to login first";
                return RedirectToAction("Login", "lecturers");
            }
            else
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }
                question question = db.questions.Find(id);
                if (question == null)
                {
                    return HttpNotFound();
                }
                ViewBag.testID = new SelectList(db.tests, "testID", "testName", question.testID);
                return View(question);
            }
           
        }

        // POST: questions/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "qID,question1,A,B,C,answer,testID")] question question)
        {
            if (ModelState.IsValid)
            {
                db.Entry(question).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Questions",new {id = question.testID });
            }
            ViewBag.testID = new SelectList(db.tests, "testID", "testName", question.testID);
            return View(question);
        }

        // GET: questions/Delete/5
        public ActionResult Delete(int? id)
        {
            if (Session["Username"] == null)//Checks if any user is logged in
            {
                Session["Error message"] = "You need to login first";
                return RedirectToAction("Login", "lecturers");
            }
            else
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }
                question question = db.questions.Find(id);
                if (question == null)
                {
                    return HttpNotFound();
                }
                return View(question);
            }
          
        }

        // POST: questions/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            question question = db.questions.Find(id);
            db.questions.Remove(question);
            db.SaveChanges();
            return RedirectToAction("Questions",new {id = question.testID });
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
